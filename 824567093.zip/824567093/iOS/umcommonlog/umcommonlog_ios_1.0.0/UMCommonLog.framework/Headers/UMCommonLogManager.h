//
//  UMCommonLogManager.h
//  testUMCommonLog
//
//  Created by 张军华 on 2017/11/28.
//  Copyright © 2017年 张军华. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface UMCommonLogManager : NSObject

+(void) setUpUMCommonLogManager;


@end
