//
//  CommentController.h
//  vitagou
//
//  Created by 高坤 on 2017/7/17.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "GKBaseViewController.h"
@interface CollectionController : GKBaseViewController
@property(nonatomic)NSInteger extraTag;
@end
