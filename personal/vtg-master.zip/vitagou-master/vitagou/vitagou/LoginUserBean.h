//
//  QQLoginUserBean.h
//  vitagou
//
//  Created by 高坤 on 2017/9/30.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LoginUser.h"
@class LoginUser;
@interface LoginUserBean : NSObject
@property (nonatomic, strong) NSString *msg;
@property (nonatomic) NSInteger status;
@property (nonatomic, strong) LoginUser *data;
@end
