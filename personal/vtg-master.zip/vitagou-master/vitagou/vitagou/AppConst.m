//
//  AppConst.m
//  vitagou
//
//  Created by Mac on 2017/5/9.
//  Copyright © 2017年 Vitagou. All rights reserved.
//


#import "AppConst.h"

NSString *const IsFristOpenApp = @"isFristOpenApp";
NSString * const GuideViewControllerDidFinish = @"GuideViewControllerDidFinish";
NSString * const HomeTableHeadViewHeightDidChange = @"HomeTableHeadViewHeightDidChange";
NSString * const ProductHeadViewHeightDidChange = @"ProductHeadViewHeightDidChange";
NSString * const HomeGoodsInventoryProblem = @"HomeGoodsInventoryProblem";
NSString * const LFBShopCarDidRemoveProductNSNotification = @"LFBShopCarDidRemoveProductNSNotification";
NSString * const LFBShopCarBuyNumberDidChangeNotification = @"LFBShopCarBuyNumberDidChangeNotification";

//轮播图URL
NSString * const WheelUrlNotification = @"wheelUrlNotification";
//goods_id
NSString * const ProductGoodsId = @"productGoodsId";
//轮播下按钮的通
NSString * const MenuViewNotification =@"MenuViewNotification";
//够实惠
NSString * const BenifitNotification =@"benifitNotification";
//品牌分类通知
NSString * const BrandCategoryNotification =@"BrandCategoryNotification";
//适用人群
NSString * const FitPeopleCellNotifacation = @"FitPeopleCellNotifacation";
//购实惠跳转详情通知
NSString * const BenifitToGoodDetailNotifacation = @"benifitToGoodDetailNotifacation";

//与详情相关的通知
NSString * const PageNumberDidChangeNotification = @"PageNumberDidChangeNotification";

NSString * const CurrentPageDidChangeNotification =@"CurrentPageDidChangeNotification";

NSString * const SelectedProductCountDidChangeNotification = @"SelectedProductCountDidChangeNotification";

NSString * const ProductInfoDidRecievedNotification = @"ProductInfoDidRecievedNotification";

NSString * const ProductBuyCountDidChangeNotification = @"ProductBuyCountDidChangeNotification";

NSString * const ProductDetailAndCommentsChangeNotification = @"productDetailAndCommentsChangeNotification";

//与分类相关的通知
NSString * const ClassifyNotification = @"classifyNotification";


//购物车
//商品是否被选择的通知
NSString * const GoodsBeChoosedNotNotification = @"goodsBeChoosedNotNotification";

NSString * const GoodsBeChoosedNotification = @"goodsBeChoosedNotification";
//单个商品数量编辑的通知
NSString * const GoodsNumEditNotification = @"goodsNumEditNotification";
//结算的通知
NSString * const GoodsSettlementNotification = @"goodsSettlementNotification";
//删除商品的通知
NSString * const GoodsDelNotification = @"goodsDelNotification";

//订单确认
NSString * const OrderConfirmChangeAddress = @"orderConfirmChangeAddress";
NSString * const OrderConfirmWeChatPay = @"orderConfirmWeChatPay";
NSString * const OrderConfirmALiPay = @"orderConfirmALiPay";
NSString * const OrderConfirmDiscounts = @"orderConfirmDiscounts";
NSString * const OrderConfirmClickPay = @"orderConfirmClickPay";
NSString * const OrderConfirmTransmitAddressData = @"orderConfirmTransmitAddressData";
NSString * const OrderConfirmNeedsItDismissAddressManager = @"orderConfirmNeedsItDismissAddressManager";
NSString * const OrderConfirmGnerate = @"orderConfirmGnerate";
NSString * const OrderConfirmGotoMyorder = @"orderConfirmGotoMyorder";
NSString * const OrderConfirmDiscount = @"orderConfirmDiscount";

const CGFloat HomeCollectionViewCellMargin = 10;
const CGFloat DefaultMargin = 10;
