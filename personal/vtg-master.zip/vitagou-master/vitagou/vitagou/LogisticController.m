//
//  LogisticController.m
//  vitagou
//
//  Created by 高坤 on 2017/8/23.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "LogisticController.h"
#import "VTGConstants.h"
#import "LogisticCell.h"
#import "LogisticData.h"
#import "Color.h"
#import "MBManager.h"
@interface LogisticController ()<UITableViewDelegate,UITableViewDataSource>
@property (strong , nonatomic)UITableView *tableView;
@property (nonatomic ,strong)NSMutableArray *dataSource;
@end
static NSString *const DCSettingCellID = @"LogisticCell";
@implementation LogisticController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setTintColor:[UIColor blackColor]];
    self.title=vtgLogistic;
    [self loadData];
}
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.frame = CGRectMake(0, 0,self.view.bounds.size.width,self.view.bounds.size.height);
        _tableView.backgroundColor=[UIColor whiteColor];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        
        [self.view addSubview:_tableView];
        
        [_tableView registerClass:[LogisticCell class] forCellReuseIdentifier:DCSettingCellID];
    }
    return _tableView;
}
- (void)loadData{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:vtgTEXTORHTML];
    NSDictionary *parameters = @{vtgParams_token:[[NSUserDefaults standardUserDefaults] objectForKey:vtgParams_token],vtgParams_Order_Id:[NSString stringWithFormat:@"%ld",_orderId]};
    [manager POST:LOGISTIC_LIST parameters:parameters
          success:^(AFHTTPRequestOperation *operation,id responseObject) {
              self.dataSource = [LogisticData mj_objectArrayWithKeyValuesArray:responseObject[vtgData]];
              if(self.dataSource.count==0){
                   [MBManager showBriefAlert:vtgNOLogistic];
              }else{
               [self.tableView reloadData ];
              }

          }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
              NSLog(@"Error: %@", error);
          }];
    
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.dataSource.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    LogisticCell *cell = [tableView dequeueReusableCellWithIdentifier:DCSettingCellID forIndexPath:indexPath];
    cell.data = self.dataSource[indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.0001;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
