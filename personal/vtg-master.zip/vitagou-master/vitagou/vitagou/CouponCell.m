//
//  CouponCell.m
//  vitagou
//
//  Created by 高坤 on 2017/8/7.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "CouponCell.h"
#import "CouponTicket.h"
#import "Color.h"
#import "VTGConstants.h"

@interface CouponCell()
@property(nonatomic,strong) CouponTicket *ticket;
@property(nonatomic,strong) UILabel *name;
@property(nonatomic,strong) UILabel *type;
@property(nonatomic,strong) UIView *rightBg;
@property(nonatomic,strong) UILabel *rightType;
@property(nonatomic,strong) UILabel *spend;
@property(nonatomic,strong) UILabel *useTime;

@end
@implementation CouponCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
        [self initView];
    }
    return self;
}
-(void)setData:(CouponTicket *)data{
    _ticket=data;
    _name.text=data.card_name;
    NSString *str;
    NSInteger value= [data.value intValue];
    NSString *timeValue= [NSString stringWithFormat: @"%ld", (long)value];
    if([data.type isEqualToString:@"1"]){
        _type.text=vtgCashCoupon;
        str = [timeValue stringByAppendingString:vtgCashCoupons];
        _rightType.text=str;
    }
    else if([data.type isEqualToString:@"2"]){
        _type.text=vtgFreeShippingCoupons;
        str = [timeValue stringByAppendingString:vtgFreeShippingCouponss];
        _rightType.text=str;
    }else{
        _type.text=vtgTaxExemptSecurities;
        str = [timeValue stringByAppendingString:vtgTaxExemptSecuritiess];
        _rightType.text=str;
    }
    if([data.t_limit isEqualToString:@"0"]){
        _spend.text=vtgNoThreshold;
    }
    else{
        _spend.text=[ vtgSpend stringByAppendingString:[ data.t_limit stringByAppendingString:vtgSpends] ];
    }
    NSTimeInterval time=[data.end_time doubleValue]+28800;
    NSDate *detaildate=[NSDate dateWithTimeIntervalSince1970:time];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *currentDateStr = [dateFormatter stringFromDate: detaildate];
    _useTime.text=[vtgEndTime stringByAppendingString:currentDateStr];
    
}
-(void)setStatus:(NSInteger )status{
    if(status==101){
        _rightBg.backgroundColor= [UIColor colorWithPatternImage:[UIImage imageNamed:@"ic_copon_not_use"]];
    }else{
        _rightBg.backgroundColor= [UIColor colorWithPatternImage:[UIImage imageNamed:@"ic_coupon_use"]];
        
    }
    
}


- (void)initView
{
    //246
    self.selectionStyle     = UITableViewCellSelectionStyleNone;
    self.backgroundColor=[UIColor whiteColor];
    UIView *grayBG= [[UIView alloc]init];
    grayBG.backgroundColor=GKCOLOR(246, 246, 246, 1);
    [self addSubview:grayBG];
    [grayBG mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(@100);
        make.left.equalTo(self).offset(10);
        make.right.equalTo(self).offset(-10);
    }];
    
    
    UILabel *couponNubmer=[[UILabel alloc]init];
    couponNubmer.text=vtgCouponNumber;
    couponNubmer.textColor = GKCOLOR(80, 80, 80, 1);
    couponNubmer.font      = [UIFont systemFontOfSize:12];
    [grayBG addSubview:couponNubmer];
    [couponNubmer mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(grayBG).offset(10);
        make.left.equalTo(grayBG).offset(10);
    }];
    self.name       = [[UILabel alloc]init];
    _name.textColor = GKCOLOR(80, 80, 80, 1);
    _name.font      = [UIFont systemFontOfSize:12];
    [grayBG addSubview:self.name];
    [self.name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(10);
        make.left.equalTo(couponNubmer.mas_right).offset(10);
    }];
    UILabel *couponType=[[UILabel alloc]init];
    couponType.text=vtgCouponType   ;
    couponType.textColor = GKCOLOR(80, 80, 80, 1);
    couponType.font      = [UIFont systemFontOfSize:12];
    [grayBG addSubview:couponType];
    [couponType mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(couponNubmer.mas_bottom).offset(10);
        make.left.equalTo(grayBG).offset(10);
    }];
    self.type       = [[UILabel alloc]init];
    _type.textColor = GKCOLOR(80, 80, 80, 1);
    _type.font      = [UIFont systemFontOfSize:12];
    [grayBG addSubview:self.type];
    [self.type mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(couponType);
        make.left.equalTo(couponType.mas_right).offset(10);
    }];
    UILabel *platform=[[UILabel alloc]init];
    platform.text=vtgCouponOnlin   ;
    platform.textColor = GKCOLOR(80, 80, 80, 1);
    platform.font      = [UIFont systemFontOfSize:12];
    [grayBG addSubview:platform];
    [platform mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(couponType.mas_bottom).offset(10);
        make.left.equalTo(grayBG).offset(10);
    }];
    UILabel  *  online       = [[UILabel alloc]init];
    online.textColor = GKCOLOR(80, 80, 80, 1);
    online.text=vtgCouponPlatfrom;
    online.font      = [UIFont systemFontOfSize:12];
    [grayBG addSubview:online];
    [online mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(platform);
        make.left.equalTo(platform.mas_right).offset(10);
    }];
    UILabel *use=[[UILabel alloc]init];
    use.text=vtgCouponUse   ;
    use.textColor = GKCOLOR(80, 80, 80, 1);
    use.font      = [UIFont systemFontOfSize:12];
    [grayBG addSubview:use];
    [use mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(platform.mas_bottom).offset(10);
        make.left.equalTo(grayBG).offset(10);
        make.bottom.equalTo(grayBG).offset(-10);
    }];
    UILabel  *  rule       = [[UILabel alloc]init];
    rule.textColor = GKCOLOR(80, 80, 80, 1);
    rule.text=vtgnotAddUse;
    rule.font      = [UIFont systemFontOfSize:12];
    [grayBG addSubview:rule];
    [rule mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(use);
        make.left.equalTo(use.mas_right).offset(10);
    }];
    
    _rightBg= [[UIView alloc]init];
    [grayBG addSubview:_rightBg];
    [_rightBg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(grayBG);
        make.width.equalTo(@120);
        make.right.equalTo(grayBG);
    }];
    _rightType       = [[UILabel alloc]init];
    _rightType.text=vtgnotAddUse;
    _rightType.font      = [UIFont systemFontOfSize:15];
    _rightType.textColor=[UIColor whiteColor];
    [_rightBg addSubview:_rightType];
    [_rightType mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_rightBg).offset(20);
        make.left.equalTo(_rightBg).offset(10);
    }];
    _spend       = [[UILabel alloc]init];
    _spend.text=vtgnotAddUse;
    _spend.font      = [UIFont systemFontOfSize:12];
    _spend.textColor=[UIColor whiteColor];
    [_rightBg addSubview:_spend];
    [_spend mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_rightType.mas_bottom).offset(10);
        make.left.equalTo(_rightBg).offset(10);
    }];
    _useTime       = [[UILabel alloc]init];
    _useTime.text=vtgnotAddUse;
    _useTime.font      = [UIFont systemFontOfSize:11];
    _useTime.textColor=[UIColor whiteColor];
    [_rightBg addSubview:_useTime];
    [_useTime mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_spend.mas_bottom).offset(10);
        make.left.equalTo(_rightBg).offset(10);
    }];
}
- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
}

@end
