//
//  LogisticData.h
//  vitagou
//
//  Created by 高坤 on 2017/8/23.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LogisticData : NSObject
@property (nonatomic, strong) NSString *station;
@property (nonatomic, strong) NSString *time;
@end
