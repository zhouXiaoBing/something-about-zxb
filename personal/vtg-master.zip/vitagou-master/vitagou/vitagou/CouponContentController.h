//
//  CouponContentController.h
//  vitagou
//
//  Created by 高坤 on 2017/8/7.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CouponContentController : UIViewController
@property(nonatomic)NSInteger status;
@end
