//
//  AddressData.m
//  loveFreshPeak
//
//  Created by ArJun on 16/5/23.
//  Copyright © 2016年 AJun. All rights reserved.
//

#import "AddressData.h"

@implementation AddressData

@end
