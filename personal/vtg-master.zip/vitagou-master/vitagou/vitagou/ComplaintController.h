//
//  ComplaintController.h
//  vitagou
//
//  Created by 高坤 on 2017/8/9.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "GKBaseViewController.h"

@interface ComplaintController : GKBaseViewController
@property(nonatomic)NSInteger status;
@end
