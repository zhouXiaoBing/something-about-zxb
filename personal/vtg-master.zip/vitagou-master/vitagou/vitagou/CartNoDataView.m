//
//  CartNoDataView.m
//  vitagou
//
//  Created by 高坤 on 2017/12/11.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "CartNoDataView.h"
#import "Color.h"
#import "AppDelegate.h"
@implementation CartNoDataView
- (instancetype)init {
    self = [super init];
    if (self){
        [self initView];
    }
    return self;
}
-(void) initView{
    
    UILabel *tvContent=[[UILabel alloc]init];
    tvContent.text=@"购物车空空如也";
    tvContent.textColor = GKCOLOR(49, 49, 49, 1);
    tvContent.font = [UIFont systemFontOfSize:14];
    [self addSubview:tvContent];
    [tvContent mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.centerX.equalTo(self);
    }];
    
    UIImageView *car  = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"ic_cart_nodata"]];
    [self addSubview:car];
    [car mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self);
        make.width.mas_equalTo(50);
        make.height.mas_equalTo(50);
        make.bottom.equalTo(tvContent.mas_top).offset(-10);
    }];
    UILabel *tvHint=[[UILabel alloc]init];
    tvHint.text=@"快去填满你的购物车吧!";
    tvHint.textColor = GKCOLOR(172, 172, 172, 1);
    tvHint.font = [UIFont systemFontOfSize:12];
    [self addSubview:tvHint];
    [tvHint mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self);
        make.top.equalTo(tvContent.mas_bottom).offset(10);
    }];
    UIButton *btnGo       = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnGo setTitleColor:GKCOLOR(172, 172, 172, 1) forState:UIControlStateNormal];
    btnGo.titleLabel.font   = [UIFont systemFontOfSize:13];
    btnGo.layer.cornerRadius = 5;
    btnGo.layer.masksToBounds = YES;
    [btnGo setTitle:@"去逛逛" forState:UIControlStateNormal];
    btnGo.layer.borderColor = GKCOLOR(133, 133, 133, 1).CGColor;
    btnGo.layer.borderWidth = 0.8;
    [btnGo addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:btnGo];
    [btnGo mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(tvHint.mas_bottom).offset(15);
        make.centerX.equalTo(self);
        make.width.mas_equalTo(70);
        make.height.mas_equalTo(30);
    }];
    
}
-(void)btnClick{
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate setRootViewController];
}
@end

