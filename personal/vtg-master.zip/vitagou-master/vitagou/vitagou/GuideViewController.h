//
//  GuideViewController.h
//  vitagou
//
//  Created by Mac on 2017/6/28.
//  Copyright © 2017年 Vitagou. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface GuideViewController : BaseViewController

@end
