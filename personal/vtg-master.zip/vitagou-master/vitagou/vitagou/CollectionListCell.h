//
//  CommentListCell.h
//  vitagou
//
//  Created by 高坤 on 2017/7/18.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol MycellDelegate <NSObject>
-(void)didClickButton:(UIButton *)button;
@end
@class CollectionData;
@class StuffData;
@interface CollectionListCell : UITableViewCell
@property (nonatomic,strong)CollectionData *data;
@property(nonatomic,strong)StuffData *stuffData;
@property(nonatomic,strong)UIButton     *w_deleteBtn;
@property(nonatomic,assign) id<MycellDelegate> delegate;
@property(nonatomic) NSInteger deleteId;
@property(nonatomic)NSInteger pageTag;
@end
