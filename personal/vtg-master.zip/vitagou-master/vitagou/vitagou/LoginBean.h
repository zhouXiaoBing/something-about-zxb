//
//  LoginBean.h
//  vitagou
//
//  Created by 高坤 on 2017/7/27.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PersonResult.h"
#import "LoginData.h"
@interface LoginBean : NSObject
@property (nonatomic,strong) PersonResult *result;
@property(nonatomic,strong) LoginData *data;
@end
