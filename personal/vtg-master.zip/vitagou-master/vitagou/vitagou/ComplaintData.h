//
//  ComplaintData.h
//  vitagou
//
//  Created by 高坤 on 2017/8/9.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ComplaintData : NSObject
@property (nonatomic,copy) NSString * amount;
@property (nonatomic,copy) NSString * complain_active;
@property (nonatomic,copy) NSString * goods_id;
@property (nonatomic,copy) NSString * img;
@property (nonatomic,copy) NSString * is_complain;
@property (nonatomic,copy) NSString * name;
@property (nonatomic,copy) NSString * order_no;
@property (nonatomic,copy) NSString * order_id;
@property (nonatomic,copy) NSString * pay_status;
@property (nonatomic,copy) NSString * refund_id;
@property (nonatomic,copy) NSString * sell_price;
@property (nonatomic,copy) NSString * seller_id;
@property (nonatomic,copy) NSString * seller_name;
@property (nonatomic,copy) NSString * time;


@end
