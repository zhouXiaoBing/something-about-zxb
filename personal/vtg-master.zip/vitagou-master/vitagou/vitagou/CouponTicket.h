//
//  CouponTicket.h
//  vitagou
//
//  Created by 高坤 on 2017/8/7.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CouponTicket : NSObject
@property (nonatomic,copy) NSString * active_time;
@property (nonatomic,copy) NSString * card_name;
@property (nonatomic,copy) NSString * card_pwd;
@property (nonatomic,copy) NSString * collection_time;
@property (nonatomic,copy) NSString * condition;
@property (nonatomic,copy) NSString * end_time;
@property (nonatomic,copy) NSString * end_time1;
@property (nonatomic,copy) NSString * id;
@property (nonatomic,copy) NSString * img;
@property (nonatomic,copy) NSString * is_close;
@property (nonatomic,copy) NSString * is_del;
@property (nonatomic,copy) NSString * is_send;
@property (nonatomic,copy) NSString * is_used;
@property (nonatomic,copy) NSString * level;
@property (nonatomic,copy) NSString * level1;
@property (nonatomic,copy) NSString * name;
@property (nonatomic,copy) NSString * order_id;
@property (nonatomic,copy) NSString * seller_id;
@property (nonatomic,copy) NSString * shop_name;
@property (nonatomic,copy) NSString * start_time;
@property (nonatomic,copy) NSString * t_limit;
@property (nonatomic,copy) NSString * ticket_id;
@property (nonatomic,copy) NSString * type;
@property (nonatomic,copy) NSString * usage_time;
@property (nonatomic,copy) NSString * user_id;
@property (nonatomic,copy) NSString * username;
@property (nonatomic,copy) NSString * value;

@end
