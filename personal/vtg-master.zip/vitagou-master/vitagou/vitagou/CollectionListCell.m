//
//  CommentListCell.m
//  vitagou
//
//  Created by 高坤 on 2017/7/18.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "CollectionListCell.h"
#import "CollectionData.h"
#import "StuffData.h"
#import "Color.h"
#import "GlobalDefine.h"
#import "VTGConstants.h"
#import "CollectionController.h"
@interface CollectionListCell ()
@property(nonatomic,strong)UIImageView  *w_goodImg;
@property(nonatomic,strong)UILabel      *w_titleLabel;

@property(nonatomic,strong) CollectionData *w_data;
@property(nonatomic,strong) StuffData *w_stuffData;
@property (nonatomic,strong)UILabel     *w_price;
@property(nonatomic,strong)UILabel      *w_market;
@end
@implementation CollectionListCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {

        [self initView];
    }
    return self;
}
-(void)setData:(CollectionData *)data{
    _pageTag=101;
    self.w_data=data;
    self.w_titleLabel.text = data.name;
    [self.w_goodImg sd_setImageWithURL: [NSURL URLWithString:[vtgUrl stringByAppendingString:data.img]]placeholderImage:[UIImage imageNamed:@"default_image"]];
    _w_price.text=[@"￥"stringByAppendingString:data.sell_price];
    NSString *market=[NSString stringWithFormat:@"¥%@",data.market_price];
    NSDictionary *attribtDic = @{NSStrikethroughStyleAttributeName: [NSNumber numberWithInteger:NSUnderlineStyleSingle]};
    NSMutableAttributedString *attribtStr = [[NSMutableAttributedString alloc]initWithString:market attributes:attribtDic];
    _w_market.attributedText = attribtStr;

}
-(void)setStuffData:(StuffData *)stuffData{
    _pageTag=102;
    self.w_stuffData=stuffData;
    self.w_titleLabel.text = stuffData.name;
    [self.w_goodImg sd_setImageWithURL: [NSURL URLWithString:[vtgUrl stringByAppendingString:stuffData.img]]placeholderImage:[UIImage imageNamed:@"default_image"]];
    _w_price.text=[@"￥"stringByAppendingString:stuffData.sell_price];
    NSString *market=[NSString stringWithFormat:@"¥%@",stuffData.market_price];
    NSDictionary *attribtDic = @{NSStrikethroughStyleAttributeName: [NSNumber numberWithInteger:NSUnderlineStyleSingle]};
    NSMutableAttributedString *attribtStr = [[NSMutableAttributedString alloc]initWithString:market attributes:attribtDic];
    _w_market.attributedText = attribtStr;
    
}

- (void)initView
{
    WS(weakSelf);
    self.selectionStyle     = UITableViewCellSelectionStyleNone;
    self.w_goodImg          = [[UIImageView alloc]init];
    self.w_goodImg.layer.borderColor = GKCOLOR(222, 222, 222, 0.8).CGColor;
    self.w_goodImg.layer.borderWidth = 0.4;
    [self addSubview:self.w_goodImg];
    [self.w_goodImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf).offset(10);
        make.left.equalTo(weakSelf).offset(10);
        make.bottom.equalTo(weakSelf).offset(-10);
        make.width.equalTo(weakSelf.w_goodImg.mas_height);
    }];
    
    self.w_titleLabel       = [[UILabel alloc]init];
    _w_titleLabel.textColor = GKCOLOR(80, 80, 80, 1);
    _w_titleLabel.font      = [UIFont systemFontOfSize:15];
    _w_titleLabel.numberOfLines = 2;
    [self addSubview:self.w_titleLabel];
    [self.w_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf).offset(10);
        make.left.equalTo(weakSelf.w_goodImg.mas_right).offset(8);
        make.right.equalTo(weakSelf).offset(-8);
    }];
  
    self.w_deleteBtn       = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.w_deleteBtn setTitleColor:GKCOLOR(214, 30, 73, 1) forState:UIControlStateNormal];
    self.w_deleteBtn.titleLabel.font   = [UIFont systemFontOfSize:13];
    self.w_deleteBtn.layer.cornerRadius = 5;
    self.w_deleteBtn.layer.masksToBounds = YES;
    self.w_deleteBtn.layer.borderColor = GKCOLOR(214, 30, 73, 1).CGColor;
    self.w_deleteBtn.layer.borderWidth = 0.3;
    [self.w_deleteBtn setTitle:@"删除" forState:UIControlStateNormal];
    [self addSubview:self.w_deleteBtn];
    [self.w_deleteBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.w_deleteBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(weakSelf).offset(-10);
        make.right.equalTo(weakSelf).offset(-10);
        make.height.mas_equalTo(25);
        make.width.mas_equalTo(60);
    }];
    self.w_price       = [[UILabel alloc]init];
    _w_price.textColor = GKCOLOR(214, 30, 73, 1);
    _w_price.font      = [UIFont systemFontOfSize:15];
    [self addSubview:self.w_price];
    [self.w_price mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.w_goodImg.mas_right).offset(8);
        make.centerY.equalTo(self.w_deleteBtn);
    }];
    
    self.w_market       = [[UILabel alloc]init];
    _w_market.textColor = GKCOLOR(80, 80, 80, 1);
    _w_market.font      = [UIFont systemFontOfSize:14];
    [self addSubview:self.w_market];
    [self.w_market mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.w_price.mas_right).offset(8);
        make.centerY.equalTo(self.w_deleteBtn);
    }];
    
    UIView *line            = [[UIView alloc]init];
    line.backgroundColor    = GKCOLOR(199, 199, 199, 1);
    [self addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf);
        make.right.equalTo(weakSelf);
        make.bottom.equalTo(weakSelf).offset(-0.7);
        make.height.mas_equalTo(0.2);
    }];

   
}
-(void)btnClick:(UIButton *)btn
{
    if(_pageTag==101){
     _deleteId = [_w_data.rid integerValue];
    }
    else{
    _deleteId =[_w_stuffData.goods_id integerValue];
    }
    btn.tag=_deleteId;
    [self.delegate didClickButton:btn];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


@end
