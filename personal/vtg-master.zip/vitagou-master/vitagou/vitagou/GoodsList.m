//
//  GoodsList.m
//  vitagou
//
//  Created by Mac on 2017/10/19.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "GoodsList.h"

@implementation GoodsList

@end

