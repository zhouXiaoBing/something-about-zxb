//
//  HomeCategoryCell.h
//  vitagou
//
//  Created by Mac on 2017/5/10.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "zxb_index_slide.h"

@interface HomeCategoryCell : UICollectionViewCell//UIcollection 子类

@property (nonatomic, strong) zxb_index_slide *cellInfo;

//@property (nonatomic, copy) ClikedCellback cellback;
@end 
