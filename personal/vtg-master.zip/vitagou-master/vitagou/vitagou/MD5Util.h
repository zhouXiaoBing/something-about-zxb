//
//  MD5Util.h
//  vitagou
//
//  Created by Mac on 2017/11/10.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

@interface NSString (MD5Util)
- (NSString *)md5;
@end

@interface NSData (MD5Util)
- (NSString*)md5;
@end
