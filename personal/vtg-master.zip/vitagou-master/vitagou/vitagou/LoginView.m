//
//  LoginView.m
//  vitagou
//
//  Created by 高坤 on 2017/7/25.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "LoginView.h"
#import "Color.h"
#import "VTGConstants.h"
#import "WeiboSDK.h"
#import "WXApi.h"
#import <TencentOpenAPI/TencentOAuth.h>
#import <TencentOpenAPI/QQApiInterfaceObject.h>
#import <TencentOpenAPI/QQApiInterface.h>
@implementation LoginView

- (instancetype)init {
    self = [super init];
    if (self){
        UIImageView *bgImg          = [[UIImageView alloc]init];
        bgImg.image                 = [UIImage imageNamed:@"ic_empty_page"];
        [self addSubview:bgImg];
        [bgImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self);
            make.left.equalTo(self);
            make.right.equalTo(self);
            
        }];
        UILabel *accoutLable          = [[UILabel alloc]init];
        accoutLable.font         = [UIFont systemFontOfSize:16];
        accoutLable.text         = @"账号";
        [self addSubview:accoutLable];
        [accoutLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self).offset(20);
            make.left.equalTo(self).offset(20);
            make.height.mas_equalTo(@40);
            
        }];
        _accoutField=[[UITextField alloc]init];
        [self addSubview:_accoutField];
        _accoutField.borderStyle=UITextBorderStyleNone;
        _accoutField.leftViewMode = UITextFieldViewModeAlways;
        _accoutField.placeholder=@"手机/QQ/微信/新浪";
        _accoutField.textColor = [UIColor darkGrayColor];
        _accoutField.font = [UIFont systemFontOfSize:13];
        [_accoutField mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(accoutLable);
            make.left.equalTo(accoutLable.mas_right).offset(10);
            make.height.mas_equalTo(@30);
            make.width.mas_equalTo(@200);
        }];
        _deleteButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_deleteButton];
        _deleteButton.tag=101;
        [_deleteButton addTarget:self action:@selector(rightClick:) forControlEvents:UIControlEventTouchUpInside];
        [_deleteButton setImage:[UIImage imageNamed:@"ic_login_delete"] forState:UIControlStateNormal];
        [_deleteButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self).offset(-10);
            make.size.mas_equalTo(CGSizeMake(30, 30));
            make.centerY.mas_equalTo(accoutLable);
            
        }];
        
        UIView *line            = [[UIView alloc]init];
        line.backgroundColor    = GKCOLOR(199, 199, 199, 1);
        [self addSubview:line];
        [line mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(25);
            make.right.equalTo(self).offset(-20);
            make.top.equalTo(accoutLable.mas_bottom).offset(2);
            make.height.mas_equalTo(0.4);
        }];
        
        UILabel *passwordLable          = [[UILabel alloc]init];
        passwordLable.font         = [UIFont systemFontOfSize:16];
        passwordLable.text         = @"密码";
        [self addSubview:passwordLable];
        [passwordLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(line.mas_bottom).offset(2);
            make.left.equalTo(self).offset(20);
            make.height.mas_equalTo(@40);
            
        }];
        _passwordField=[[UITextField alloc]init];
        [self addSubview:_passwordField];
        _passwordField.borderStyle=UITextBorderStyleNone;
        _passwordField.leftViewMode = UITextFieldViewModeAlways;
        //密码样式
        _passwordField.secureTextEntry=YES;
        _passwordField.placeholder=@"请输入密码";
        _passwordField.textColor = [UIColor darkGrayColor];
        _passwordField.font = [UIFont systemFontOfSize:13];
        
        [_passwordField mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(passwordLable);
            make.left.equalTo(passwordLable.mas_right).offset(10);
            make.height.mas_equalTo(@30);
            make.width.mas_equalTo(@200);
        }];
        NSString* accout=[[NSUserDefaults standardUserDefaults] objectForKey:vtgAccout];
        NSString* password=[[NSUserDefaults standardUserDefaults] objectForKey:vtgPassWord];
        if(!(accout==nil)){
            _accoutField.text=accout;
        }
        if(!(password==nil)){
            _passwordField.text=password;
        }
        _passwordButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_passwordButton];
        _passwordButton.tag=102;
        [_passwordButton addTarget:self action:@selector(rightClick:) forControlEvents:UIControlEventTouchUpInside];
        [_passwordButton setImage:[UIImage imageNamed:@"ic_login_password"] forState:UIControlStateNormal];
        [_passwordButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self).offset(-10);
            make.size.mas_equalTo(CGSizeMake(30, 30));
            make.centerY.mas_equalTo(passwordLable);
            
        }];
        
        UIView *passwordline            = [[UIView alloc]init];
        passwordline.backgroundColor    = GKCOLOR(199, 199, 199, 1);
        [self addSubview:passwordline];
        [passwordline mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(25);
            make.right.equalTo(self).offset(-20);
            make.top.equalTo(passwordLable.mas_bottom).offset(2);
            make.height.mas_equalTo(0.4);
        }];
        UIButton *loginButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:loginButton];
        loginButton.backgroundColor=GKCOLOR(205, 8, 50, 1);
        loginButton.titleLabel.font = [UIFont systemFontOfSize: 16];
        [loginButton.layer setMasksToBounds:YES];
        [loginButton.layer setCornerRadius:5.0];
        loginButton.tag=101;
        [loginButton addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [loginButton setTitle:@"登陆" forState:UIControlStateNormal];
        [loginButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self).offset(-30);
            make.left.equalTo(self).offset(30);
            make.top.equalTo(passwordline.mas_bottom).offset(50);
            make.height.equalTo(@40);
            
        }];
        
        UIButton *registButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:registButton];
        registButton.titleLabel.font = [UIFont systemFontOfSize: 16];
        [registButton.layer setMasksToBounds:YES];
        [registButton.layer setCornerRadius:5.0];
        registButton.layer.borderWidth = 1;
        registButton.layer.borderColor =[UIColor grayColor].CGColor;
        [registButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        registButton.tag=102;
        [registButton addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [registButton setTitle:@"免费注册" forState:UIControlStateNormal];
        [registButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self).offset(-30);
            make.left.equalTo(self).offset(30);
            make.top.equalTo(loginButton.mas_bottom).offset(10);
            make.height.equalTo(@40);
            
        }];
        UIButton *forgetpasswordButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:forgetpasswordButton];
        forgetpasswordButton.tag=103;
        [forgetpasswordButton addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [forgetpasswordButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [forgetpasswordButton setTitle:@"忘记密码?" forState:UIControlStateNormal];
        forgetpasswordButton.titleLabel.font = [UIFont systemFontOfSize: 14];
        [forgetpasswordButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self);
            make.top.equalTo(registButton.mas_bottom).offset(10);
            
        }];
        
        
        UIView *left            = [[UIView alloc]init];
        left.backgroundColor    = GKCOLOR(199, 199, 199, 1);
        [self addSubview:left];
        [left mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(10);
            make.bottom.equalTo(self).offset(-100);
            make.height.mas_equalTo(1);
            make.width.mas_equalTo((self.bounds.size.height-150)/2);
        }];
        UILabel *center          = [[UILabel alloc]init];
        center.font         = [UIFont systemFontOfSize:16];
        center.textColor=[UIColor grayColor];
        center.text         = @"第三方登录";
        center.textAlignment = NSTextAlignmentCenter;
        [self addSubview:center];
        [center mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(left);
            make.centerX.equalTo(self);
            make.left.equalTo(left.mas_right).offset(20);
            make.width.mas_equalTo(90);
            
        }];
        UIView *right            = [[UIView alloc]init];
        right.backgroundColor    = GKCOLOR(199, 199, 199, 1);
        [self addSubview:right];
        [right mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(center.mas_right).offset(20);
            make.right.equalTo(self).equalTo(@-10);
            make.centerY.equalTo(left);
            make.height.mas_equalTo(1);
            make.width.mas_equalTo((self.bounds.size.height-150)/2);
        }];
        
        UIView * leftbottomBg= [[UIView alloc]init];
        leftbottomBg.tag=101;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(cliicked:)];
        [leftbottomBg addGestureRecognizer:tap];
        [self addSubview:leftbottomBg];
        [leftbottomBg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(left.mas_bottom).offset(20);
            make.left.equalTo(self).offset(20);
            make.height.mas_equalTo(60);
            make.width.mas_equalTo(100);
        }];
        
        UIView *centerbottomBg= [[UIView alloc]init];
        centerbottomBg.tag=102;
        UITapGestureRecognizer *tapCenter = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(cliicked:)];
        [centerbottomBg addGestureRecognizer:tapCenter];
        [self addSubview:centerbottomBg];
        [centerbottomBg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(leftbottomBg.mas_right);
            make.top.equalTo(right.mas_bottom).offset(20);
            make.height.mas_equalTo(60);
            make.width.mas_equalTo(100);
        }];
        
        UIView *rightbottomBg= [[UIView alloc]init];
        rightbottomBg.tag=103;
        UITapGestureRecognizer *tapRight = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(cliicked:)];
        [rightbottomBg addGestureRecognizer:tapRight];
        [self addSubview:rightbottomBg];
        [rightbottomBg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self).offset(-20);
            make.top.equalTo(right.mas_bottom).offset(20);
            make.height.mas_equalTo(60);
            make.width.mas_equalTo(100);
        }];
        UIImageView *weibo = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"ic_weibo"]];
        [leftbottomBg addSubview:weibo];
        UIImageView *wechat = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"ic_wechat"]];
        [centerbottomBg addSubview:wechat];
        UIImageView *qq = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"ic_qq"]];
        [rightbottomBg addSubview:qq];
        [weibo mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(leftbottomBg);
            make.centerX.equalTo(leftbottomBg);
        }];
        [wechat mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(centerbottomBg);
            make.top.equalTo(leftbottomBg);
            
        }];
        [qq mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(rightbottomBg);
            make.top.equalTo(leftbottomBg);
            
        }];
        UILabel *leftLabel          = [[UILabel alloc]init];
        leftLabel.textColor         = [UIColor grayColor];
        leftLabel.text=@"微博";
        leftLabel.font              = [UIFont systemFontOfSize:14];
        leftLabel.textAlignment     = NSTextAlignmentCenter;
        [leftbottomBg addSubview:leftLabel];
        [leftLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(weibo);
            make.right.equalTo(weibo);
            make.top.equalTo(weibo.mas_bottom).offset(4);
            make.height.mas_equalTo(15);
        }];
        UILabel *centerLabel          = [[UILabel alloc]init];
        centerLabel.textColor         = [UIColor grayColor];
        centerLabel.font              = [UIFont systemFontOfSize:14];
        centerLabel.textAlignment     = NSTextAlignmentCenter;
        centerLabel.text              = @"微信";
        [centerbottomBg addSubview:centerLabel];
        [centerLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(wechat);
            make.right.equalTo(wechat);
            make.top.equalTo(wechat.mas_bottom).offset(4);
            make.height.mas_equalTo(15);
        }];
        
        UILabel * rightLabel         = [[UILabel alloc]init];
        rightLabel.textColor        = [UIColor grayColor];
        rightLabel.text              = @"QQ";
        rightLabel.font             = [UIFont systemFontOfSize:14];
        rightLabel.textAlignment    = NSTextAlignmentCenter;
        [rightbottomBg addSubview:rightLabel];
        [rightLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(qq);
            make.right.equalTo(qq);
            make.top.equalTo(qq.mas_bottom).offset(4);
            make.height.mas_equalTo(15);
            
        }];
        if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"weixin://"]]==NO) {
            centerbottomBg.hidden=YES;
        }
        if([WeiboSDK isWeiboAppInstalled]==NO){
            leftbottomBg.hidden=YES;
        }
        if([TencentOAuth iphoneQQInstalled]==NO){
            rightbottomBg.hidden=YES;
            
        }
        if(leftbottomBg.hidden==YES){
            if(centerbottomBg.hidden==YES){
                [rightbottomBg mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.centerX.equalTo(self);
                }];
            }
            else if(rightbottomBg.hidden==YES){
                [centerbottomBg mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.centerX.equalTo(self);
                }];
            }
            else{
                [centerbottomBg mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.left.equalTo(self);
                }];
                [rightbottomBg mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.right.equalTo(self);
                }];
            }
            
            
        }
        if(centerbottomBg.hidden==YES){
            
            if(leftbottomBg.hidden==YES){
                [rightbottomBg mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.centerX.equalTo(self);
                }];
            }
            else if(rightbottomBg.hidden==YES){
                [leftbottomBg mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.centerX.equalTo(self);
                }];
            }
        }
        
        if(rightbottomBg.hidden==YES){
            if(centerbottomBg.hidden==YES){
                [leftbottomBg mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.centerX.equalTo(self);
                }];
            }else if(leftbottomBg.hidden==YES){
                [centerbottomBg mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.centerX.equalTo(self);
                }];
            }
            else{
                
                [leftbottomBg mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.left.equalTo(self).offset(30);
                }];
                [centerbottomBg mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.right.equalTo(self);
                }];
            }
        }
    }
    return self;
}
-(void)rightClick:(UIButton *)btn{
    if(btn.tag==101){
        _accoutField.text=nil;
    }
    else{
        if( _passwordField.secureTextEntry==YES){
            [_passwordButton setImage:[UIImage imageNamed:@"ic_login_password_gray"] forState:UIControlStateNormal];
            _passwordField.secureTextEntry=NO;
        }
        else{
            [_passwordButton setImage:[UIImage imageNamed:@"ic_login_password"] forState:UIControlStateNormal];
            _passwordField.secureTextEntry=YES;
        }
    }
}
-(void)cliicked:(UITapGestureRecognizer *)tap
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.tag=tap.view.tag;
    [self.delegate otherLoginClick:btn];
}
-(void)btnClick:(UIButton *)btn
{
    if(self.callback){
        self.callback(HeadViewItemTypeHot,btn.tag);
    };
}
@end

