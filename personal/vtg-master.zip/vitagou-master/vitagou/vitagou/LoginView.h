//
//  LoginView.h
//  vitagou
//
//  Created by 高坤 on 2017/7/25.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol LoginViewDelegate <NSObject>
-(void) otherLoginClick:(UIButton *)btn;
@end
@interface LoginView : UIView
@property (strong,nonatomic)UITextField *accoutField;
@property (strong,nonatomic)UITextField *passwordField;
@property (strong , nonatomic)UIButton *deleteButton;
@property (strong , nonatomic)UIButton *passwordButton;
@property (nonatomic, copy) ClikedCallback callback;
@property(nonatomic,assign) id<LoginViewDelegate>delegate;

- (instancetype)init;
@end
