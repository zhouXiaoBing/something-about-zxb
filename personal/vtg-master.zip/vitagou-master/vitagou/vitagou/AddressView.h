//
//  AddressView.h
//  vitagou
//
//  Created by 高坤 on 2017/9/4.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AddressSelectDelegate <NSObject>
-(void)didClickButton;
@end
@interface AddressView : UIView

- (instancetype)init;
@property (nonatomic,strong)UITextField *addressNameField;
@property (nonatomic,strong)UITextField *phoneField;
@property (nonatomic,strong)UITextField *idCardField;
@property (nonatomic,strong)UILabel *addressField;
@property (nonatomic,strong)UITextField *locationField;
@property(nonatomic,assign) id<AddressSelectDelegate> delegate;
@end
