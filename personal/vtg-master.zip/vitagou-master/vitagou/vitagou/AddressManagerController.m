//
//  AddressManagerController.m
//  vitagou
//
//  Created by 高坤 on 2017/7/28.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "AddressManagerController.h"
#import "VTGConstants.h"
#import "AddressCell.h"
#import "AddressManagerData.h"
#import "Color.h"
#import "ManageAddressController.h"
@interface AddressManagerController ()<UITableViewDelegate,UITableViewDataSource,MycellDelegate,AddressDelegate>
@property (strong , nonatomic)UITableView *tableView;
@property (nonatomic ,strong)NSMutableArray *dataSource;
@end
static NSString *const DCSettingCellID = @"AddressListCell";
@implementation AddressManagerController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=vtgAddressManage;
    [self loadData];
    [self.navigationController.navigationBar setTintColor:[UIColor blackColor]];
    UIButton *commitButton = [UIButton buttonWithType:UIButtonTypeCustom];
    commitButton.backgroundColor=GKCOLOR(205, 8, 50, 1);
    commitButton.titleLabel.font = [UIFont systemFontOfSize: 16];
    [commitButton addTarget:self action:@selector(addAddress) forControlEvents:UIControlEventTouchUpInside];
    [commitButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [commitButton setTitle:vtgAddNewAddress forState:UIControlStateNormal];
    [self.view addSubview:commitButton];
    [commitButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view);
        make.left.equalTo(self.view);
        make.bottom.equalTo(self.view);
        make.height.mas_equalTo(50);
    }];
    
    
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.frame = CGRectMake(0, 0,self.view.bounds.size.width,self.view.bounds.size.height-50);
        _tableView.backgroundColor=[UIColor whiteColor];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        
        [self.view addSubview:_tableView];
        
        [_tableView registerClass:[AddressCell class] forCellReuseIdentifier:DCSettingCellID];
    }
    
    return _tableView;
}
- (void)loadData{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:vtgTEXTORHTML];
    NSDictionary *parameters = @{vtgParams_token:[[NSUserDefaults standardUserDefaults] objectForKey:vtgParams_token]};
    [manager POST:ADDRESSLIST parameters:parameters
          success:^(AFHTTPRequestOperation *operation,id responseObject) {
              self.dataSource = [AddressManagerData mj_objectArrayWithKeyValuesArray:responseObject[vtgData]];
              [self.tableView reloadData ];
          }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
              NSLog(@"Error: %@", error);
          }];
    
    
}
-(void)breakSuccessButton{
    [self loadData];
}
-(void)addAddress{
    //新增收货地址
    ManageAddressController *addAddress=[[ManageAddressController alloc]init];
    addAddress.status=1;
    addAddress.delegate=self;
    [self.navigationController pushViewController:addAddress animated:YES];
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.dataSource.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    AddressCell *cell = [tableView dequeueReusableCellWithIdentifier:DCSettingCellID forIndexPath:indexPath];
    cell.data = self.dataSource[indexPath.row];
    cell.owner=self;
    cell.delegate=self;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 150;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.0001;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(_isOrderConfirm==YES){
        AddressManagerData *addressData=[[AddressManagerData alloc]init];
        addressData=self.dataSource[indexPath.row];
        [self.navigationController popViewControllerAnimated:YES];
        [self.delegate selectAddress:addressData];
    }
}

-(void)didClickButton:(UIButton *)button
{
    //设为默认
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:vtgTEXTORHTML];
    NSString *userToken=[[NSUserDefaults standardUserDefaults] objectForKey:vtgParams_token];
    NSString *addressId= [NSString stringWithFormat:@"%ld",button.tag];
    NSDictionary *parameters = @{vtgParams_token:userToken,vtgParams_Address_Id:addressId};
    [manager POST:DEFAULT_ADDRESS parameters:parameters
          success:^(AFHTTPRequestOperation *operation,id responseObject) {
              [self loadData];
          }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
              NSLog(@"Error: %@", error);
          }];
    
}
-(void)clickButton:(UIButton *)button extraAddress:(ExtraAddress *)address{
    if(button.tag==102){
        ManageAddressController *view=[[ManageAddressController alloc]init];
        view.status=2;
        view.address_id=address.address_id;
        view.accept_name=address.accept_name;
        view.address=address.address;
        view.address_detail=address.address_detail;
        view.mobile=address.mobile;
        view.Idcard=address.Idcard;
        view.province=address.province;
        view.city=address.city;
        view.area=address.area;
        view.Idimg_zm=address.Idimg_zm;
        view.Idimg_fm=address.Idimg_fm;
        view.delegate=self;
        [self.navigationController pushViewController:view animated:YES];
    }else{
        //删除
        UIAlertController *uiAlert =[UIAlertController alertControllerWithTitle:vtgDeleteAddress message:vtgIsDelete preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okButton = [UIAlertAction actionWithTitle:vtgSure style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
            manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:vtgTEXTORHTML];
            NSString *addressId= address.address_id;
            NSString *userToken=[[NSUserDefaults standardUserDefaults] objectForKey:vtgParams_token];
            NSDictionary *parameters = @{vtgParams_token:userToken,vtgParams_Address_Id:addressId};
            
            [manager POST:DELETE_ADDRESS parameters:parameters
                  success:^(AFHTTPRequestOperation *operation,id responseObject) {
                      [self loadData];
                  }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
                      NSLog(@"Error: %@", error);
                  }];
            
        }];
        UIAlertAction *cancelButton = [UIAlertAction actionWithTitle:vtgCancel style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        }];
        [uiAlert addAction:okButton];
        [uiAlert addAction:cancelButton];
        [self presentViewController:uiAlert animated:YES completion:nil];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
