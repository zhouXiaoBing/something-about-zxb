//
//  LoginController.m
//  vitagou
//
//  Created by 高坤 on 2017/7/25.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "LoginController.h"
#import "LoginView.h"
#import "RegistController.h"
#import "MBManager.h"
#import "VTGConstants.h"
#import "LoginBean.h"
#import "LoginData.h"
#import "PersonResult.h"
#import "LoginUser.h"
#import "LoginUserBean.h"
#import "ThirdPartyLoginManager.h"
#import "TokenResut.h"
#define kWeixinAppId    @"wx15b01dbdd25b34bb"
#define kWeixinAppSecret @"695483d609d637f926834b4fb311e25c"
#import "AppDelegate.h"
@interface LoginController ()<LoginViewDelegate>
@property(nonatomic,strong) NSString *token;
@property(nonatomic,strong) LoginView *loginView;
@property(nonatomic,strong) AFHTTPRequestOperationManager *manager;
    @end

@implementation LoginController
    
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setTintColor:[UIColor blackColor]];
    self.title=vtgLogin;
    UIButton*leftButton = [[UIButton alloc]initWithFrame:CGRectMake(0,0,40,40)];
    [leftButton setImage:[UIImage imageNamed:@"ic_title_back_page"] forState:UIControlStateNormal];
    [leftButton addTarget:self action:@selector(titleBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem*leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem= leftItem;
    _manager = [AFHTTPRequestOperationManager manager];
    _manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html",@"text/plain", nil];
    NSDictionary *parameters = @{@"secret":vtgParams_secret_value};
    [_manager POST:GETTOKEN parameters:parameters
           success:^(AFHTTPRequestOperation *operation,id responseObject) {
               TokenResut *result = [TokenResut mj_objectWithKeyValues:responseObject];
               _token=result.token;
           }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
               NSLog(@"Error: %@", error);
           }];

    [self initView ];
}
-(void) titleBack{
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate setRootViewController];
}
-(void)initView {
    self.loginView=[[LoginView alloc]init];
    _loginView.delegate=self;
    [self.view addSubview:self.loginView];
    [self.loginView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view);
        make.width.equalTo(self.view);
        make.bottom.equalTo(self.view);
    }];
    __weak typeof(self) buttonSelf = self;
    _loginView.callback= ^(HeadViewItemType type,NSInteger tag){
        [buttonSelf buttonClick:type tag:tag];
    };
    
}
-(void)buttonClick:(HeadViewItemType)type tag:(NSInteger)tag{
    if(tag==101){
        [self btnLogin];
    }
    else if(tag==102){
        RegistController *view=[[RegistController alloc]init];
        view.extraTag=101;
        [self.navigationController pushViewController:view animated:YES];
    }
    else{
        RegistController *view=[[RegistController alloc]init];
        view.extraTag=102;
        [self.navigationController pushViewController:view animated:YES];
    }
}
-(void)btnLogin{
    if(self.loginView.accoutField.text.length==0){
        [MBManager showBriefAlert:vtgInputAccout];
    }
    else if(self.loginView.passwordField.text.length==0){
        [MBManager showBriefAlert:vtgInputPassWord];
    }
    else{
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:vtgTEXTORHTML];
        NSDictionary *parameters = @{vtgParams_accout:self.loginView.accoutField.text,vtgParams_password:self.loginView.passwordField.text};
        [manager POST:LOGIN parameters:parameters
              success:^(AFHTTPRequestOperation *operation,id responseObject) {
                  LoginBean *bean = [LoginBean mj_objectWithKeyValues:responseObject];
                  PersonResult *result = bean.result;
                  LoginData *data = bean.data;
                  if([result.msg isEqualToString:vtgSuccess]){
                      [[NSUserDefaults standardUserDefaults] setObject:data.user_token forKey:vtgParams_token];
                      [[NSUserDefaults standardUserDefaults] setObject:self.loginView.accoutField.text forKey:vtgAccout];
                      [[NSUserDefaults standardUserDefaults] setObject:self.loginView.passwordField.text forKey:vtgPassWord];
                      [MBManager showBriefAlert:vtgLoginSucess];
                      [self.delegate didClickButton];
                      [self.navigationController popViewControllerAnimated:YES];
                      
                  }
                  else{
                  [MBManager showBriefAlert:result.msg];
                  }
              }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
                  NSLog(@"Error: %@", error);
              }];
        
 
}
}
-(void)otherLoginClick:(UIButton *)btn{
     LoginType loginType;
    if(btn.tag==101){
        loginType=LoginTypeWeiBo;
    }else if(btn.tag==102){
        loginType=LoginTypeWeiXin;
    }else{
        loginType=LoginTypeTencent;
    }
    NSInteger tag;
    tag=btn.tag;
    [ThirdPartyLoginManager getUserInfoWithLoginType:loginType result:^(NSDictionary *LoginResult, NSString *error) {
        if (LoginResult) {
            /**  weibo性别，m：男、f：女、n：未知 qq性别，男、女、未知  字符串提醒 微信性别，1:男、2:女、未知  字符串提醒*/
//            self.userName.text = LoginResult[@"third_name"];
            //微博登录
            if(tag==101){

                NSString *sex;
                if([LoginResult[@"third_gender"] isEqualToString:@"m"]){
                sex=@"1";
                }else if ([LoginResult[@"third_gender"] isEqualToString:@"f"]){
                sex=@"2";
                }else{
                sex=@"0";
                }

                NSDictionary *parameters = @{vtgParams_id:LoginResult[@"third_id"],vtgParams_nickName:LoginResult[@"third_name"],
                 vtgParams_Sex:sex,vtgParams_headimgUrl:LoginResult[@"third_image"],vtgParams_LoginToken:_token};
                
                [_manager POST:APP_SETWEIBOUSER
                    parameters:parameters
                      success:^(AFHTTPRequestOperation *operation,id responseObject) {
                          
                          LoginUserBean *bean = [LoginUserBean mj_objectWithKeyValues:responseObject];
                          LoginUser *user = bean.data;
                          if(bean.status==1){
                              [self Login:user.username setPassWord:user.password];
                          }else{
                              [MBManager showBriefAlert:@"登录失败"];
                          }
                      }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
                          NSLog(@"Error: %@", error);
                      }];

        }
            //微信登录
            else if(tag==102){
                NSDictionary *parameters = @{@"unionid":LoginResult[@"third_unionid"],@"openid":LoginResult[@"third_id"],@"nickname":LoginResult[@"third_name"],@"sex":LoginResult[@"third_gender"],@"headimgurl":LoginResult[@"third_image"]};
                [_manager POST:SET_WEIXIN_USER parameters:parameters
                       success:^(AFHTTPRequestOperation *operation,id responseObject) {
                           LoginUserBean*bean = [LoginUserBean mj_objectWithKeyValues:responseObject];
                           LoginUser *user = bean.data;
                           if(bean.status==1){
                               [self Login:user.username setPassWord:user.password];
                           }else{
                               
                               [MBManager showBriefAlert:@"登录失败"];
                           }
                       }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
                           NSLog(@"Error: %@", error);
                       }];
            }
            //qq登录
            else{
                NSString *sex;
                if([LoginResult[@"third_gender"] isEqualToString:@"男"]){
                    sex=@"1";
                }else if ([LoginResult[@"third_gender"] isEqualToString:@"女"]){
                    sex=@"2";
                }else{
                    sex=@"0";
                }
                NSDictionary *parameters = @{vtgParams_open:LoginResult[@"third_id"],vtgParams_nickName:LoginResult[@"third_name"],
                                             vtgParams_Sex:sex,vtgParams_headimgUrl:LoginResult[@"third_image"],vtgParams_LoginToken:_token};
                [_manager POST:APP_SETQQUSER parameters:parameters
                       success:^(AFHTTPRequestOperation *operation,id responseObject) {
                           LoginUserBean*bean = [LoginUserBean mj_objectWithKeyValues:responseObject];
                           LoginUser *user = bean.data;
                           if(bean.status==1){
                               [self Login:user.username setPassWord:user.password];
                           }else{
                               
                               [MBManager showBriefAlert:@"登录失败"];
                           }
                       }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
                           NSLog(@"Error: %@", error);
                       }];
            }
            
        }
        else{
            NSLog(@"%@",error);
        }
  
    }];
    
}
//-(void)weixinLogin:(NSString *)openId setUnionId:(NSString *)unionid{
//    NSDictionary *parameters = @{@"openid":openId,@"unionid":unionid};
//    [_manager POST:WEIXIN_LONGIN parameters:parameters
//           success:^(AFHTTPRequestOperation *operation,id responseObject) {
//               NSLog(@"weixinlogin%@",responseObject);
//           }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
//               NSLog(@"Error: %@", error);
//           }];
//
//}
-(void)Login:(NSString *)userName setPassWord:(NSString *)password{
    NSDictionary *parameters = @{@"user_login":userName,@"password":password};
    [_manager POST:LOGIN parameters:parameters
           success:^(AFHTTPRequestOperation *operation,id responseObject) {
               NSLog(@"%@",responseObject);
               [MBManager showBriefAlert:vtgLoginSucess];
               LoginBean *bean = [LoginBean mj_objectWithKeyValues:responseObject];
               LoginData *data = bean.data;
               [[NSUserDefaults standardUserDefaults] setObject:data.user_token forKey:vtgParams_token];
                 [self.delegate didClickButton];
              [self.navigationController popViewControllerAnimated:YES];
           }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
               NSLog(@"Error: %@", error);
           }];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
    
    
    @end
