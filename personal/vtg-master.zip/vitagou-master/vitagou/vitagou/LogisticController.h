//
//  LogisticController.h
//  vitagou
//
//  Created by 高坤 on 2017/8/23.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "GKBaseViewController.h"

@interface LogisticController : GKBaseViewController
@property(nonatomic)NSInteger orderId;
@end
