//
//  QQLoginUserBean.m
//  vitagou
//
//  Created by 高坤 on 2017/9/30.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "LoginUserBean.h"

@implementation LoginUserBean

@end
