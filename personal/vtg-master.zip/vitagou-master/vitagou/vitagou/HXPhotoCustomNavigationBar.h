//
//  HXPhotoCustomNavigationBar.h
//  vitagou
//
//  Created by 高坤 on 2017/10/17.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HXPhotoCustomNavigationBar : UINavigationBar

@end
