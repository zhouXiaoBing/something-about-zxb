//
//  GKCountDownView.m
//  vitagou
//  vtg特定倒计时
//  Created by 高坤 on 2017/9/7.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "GKCountDownView.h"
#import "Color.h"
@interface GKCountDownView(){
    NSTimer *timer;
}
@property (nonatomic,strong)UIButton *day;
@property (nonatomic,strong)UIButton *hourFirst;
@property (nonatomic,strong)UIButton *hourSecond;
@property (nonatomic,strong)UIButton *minuteFirst;
@property (nonatomic,strong)UIButton *minuteSecond;
@property (nonatomic,strong)UIButton *mFirst;
@property (nonatomic,strong)UIButton *mSecond;
@end
@implementation GKCountDownView
// 创建单例
+ (instancetype)shareCountDown{
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[GKCountDownView alloc] init];
    });
    return instance;
}

+ (instancetype)countDown{
    return [[self alloc] init];
}
- (instancetype)init {
    
    self = [super init];
    if (self){
       _day = [UIButton buttonWithType:UIButtonTypeCustom];
        [_day setBackgroundImage:[UIImage imageNamed:@"ic_timedown_dark"] forState:UIControlStateNormal];
        _day.titleLabel.font = [UIFont systemFontOfSize: 16];
        [_day setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self addSubview:_day];
        [_day mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self);
            make.bottom.equalTo(self);
            make.height.mas_equalTo(30);
            make.width.mas_equalTo(20);
        }];
        UILabel * dayLable=[[UILabel alloc]init];
        dayLable.textColor = GKCOLOR(49, 49, 49, 1);
        dayLable.text=@"天";
        dayLable.font      = [UIFont systemFontOfSize:12];
        [self addSubview:dayLable];
        [dayLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(_day);
            make.left.equalTo(_day.mas_right).offset(5);
        }];
        _hourFirst = [UIButton buttonWithType:UIButtonTypeCustom];
        [_hourFirst setBackgroundImage:[UIImage imageNamed:@"ic_timedown_dark"] forState:UIControlStateNormal];
        _hourFirst.titleLabel.font = [UIFont systemFontOfSize: 16];
        [_hourFirst setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self addSubview:_hourFirst];
        [_hourFirst mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(dayLable.mas_right).offset(5);
            make.bottom.equalTo(self);
            make.height.mas_equalTo(30);
            make.width.mas_equalTo(15);
        }];
        _hourSecond = [UIButton buttonWithType:UIButtonTypeCustom];
        [_hourSecond setBackgroundImage:[UIImage imageNamed:@"ic_timedown_dark"] forState:UIControlStateNormal];
        _hourSecond.titleLabel.font = [UIFont systemFontOfSize: 16];
        [_hourSecond setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self addSubview:_hourSecond];
        [_hourSecond mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_hourFirst.mas_right).offset(3);
            make.bottom.equalTo(self);
            make.height.mas_equalTo(30);
            make.width.mas_equalTo(15);
        }];
        UILabel * hourLable=[[UILabel alloc]init];
        hourLable.textColor = GKCOLOR(49, 49, 49, 1);
        hourLable.text=@"时";
        hourLable.font      = [UIFont systemFontOfSize:12];
        [self addSubview:hourLable];
        [hourLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(_day);
            make.left.equalTo(_hourSecond.mas_right).offset(5);
        }];
        _minuteFirst = [UIButton buttonWithType:UIButtonTypeCustom];
        [_minuteFirst setBackgroundImage:[UIImage imageNamed:@"ic_timedown_dark"] forState:UIControlStateNormal];
        _minuteFirst.titleLabel.font = [UIFont systemFontOfSize: 16];
        [_minuteFirst setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self addSubview:_minuteFirst];
        [_minuteFirst mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(hourLable.mas_right).offset(5);
            make.bottom.equalTo(self);
            make.height.mas_equalTo(30);
            make.width.mas_equalTo(15);
        }];
        _minuteSecond = [UIButton buttonWithType:UIButtonTypeCustom];
        [_minuteSecond setBackgroundImage:[UIImage imageNamed:@"ic_timedown_dark"] forState:UIControlStateNormal];
        _minuteSecond.titleLabel.font = [UIFont systemFontOfSize: 16];
        [_minuteSecond setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self addSubview:_minuteSecond];
        [_minuteSecond mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_minuteFirst.mas_right).offset(3);
            make.bottom.equalTo(self);
            make.height.mas_equalTo(30);
            make.width.mas_equalTo(15);
        }];
        UILabel * minuteLable=[[UILabel alloc]init];
        minuteLable.textColor = GKCOLOR(49, 49, 49, 1);
        minuteLable.text=@"分";
        minuteLable.font      = [UIFont systemFontOfSize:12];
        [self addSubview:minuteLable];
        [minuteLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(_day);
            make.left.equalTo(_minuteSecond.mas_right).offset(5);
        }];

        _mFirst = [UIButton buttonWithType:UIButtonTypeCustom];
        [_mFirst setBackgroundImage:[UIImage imageNamed:@"ic_timedown_red"] forState:UIControlStateNormal];
        _mFirst.titleLabel.font = [UIFont systemFontOfSize: 16];
        [_mFirst setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self addSubview:_mFirst];
        [_mFirst mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(minuteLable.mas_right).offset(5);
            make.bottom.equalTo(self);
            make.height.mas_equalTo(30);
            make.width.mas_equalTo(15);
        }];
        _mSecond = [UIButton buttonWithType:UIButtonTypeCustom];
        [_mSecond setBackgroundImage:[UIImage imageNamed:@"ic_timedown_red"] forState:UIControlStateNormal];
        _mSecond.titleLabel.font = [UIFont systemFontOfSize: 16];
        [_mSecond setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self addSubview:_mSecond];
        [_mSecond mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_mFirst.mas_right).offset(3);
            make.bottom.equalTo(self);
            make.height.mas_equalTo(30);
            make.width.mas_equalTo(15);
        }];

        
    }
    return self;
}


// 拿到外界传来的时间戳
- (void)setTimestamp:(NSInteger)timestamp{
    _timestamp = timestamp;
 
    if (timer==nil ) {
        
        timer=[NSTimer timerWithTimeInterval:1 target:self selector:@selector(timer:) userInfo:nil repeats:YES];
        NSRunLoop*runLoop=[NSRunLoop currentRunLoop];
        [runLoop addTimer:timer forMode:NSDefaultRunLoopMode];
        [timer fire];
        
    }

}

-(void)dealloc{
    [timer invalidate];
    timer=nil;
}

-(void)timer:(NSTimer*)timerr{
    _timestamp--;
    [self getDetailTimeWithTimestamp:_timestamp];
    if (_timestamp == 0) {
        [timer invalidate];
        timer = nil;
        // 执行block回调
        self.timerStopBlock();
    }
}

- (void)getDetailTimeWithTimestamp:(NSInteger)timestamp{
    NSInteger ms = timestamp;
    NSInteger ss = 1;
    NSInteger mi = ss * 60;
    NSInteger hh = mi * 60;
    NSInteger dd = hh * 24;
    NSInteger day = ms / dd;
    NSInteger hour = (ms - day * dd) / hh;
    NSInteger minute = (ms - day * dd - hour * hh) / mi;
    NSInteger second = (ms - day * dd - hour * hh - minute * mi) / ss;
    NSString *time;
    if(day<10){
        time=[@"0"stringByAppendingString:[NSString stringWithFormat:@"%zd",day]];
    }
    else{
        time=[NSString stringWithFormat:@"%zd",day];
    }
     [_day setTitle:time forState:UIControlStateNormal];
    [_hourFirst setTitle:[NSString stringWithFormat:@"%zd",hour/10] forState:UIControlStateNormal];
     [_hourSecond setTitle:[NSString stringWithFormat:@"%zd",hour%10] forState:UIControlStateNormal];
    [_minuteFirst setTitle:[NSString stringWithFormat:@"%zd",minute/10] forState:UIControlStateNormal];
    [_minuteSecond setTitle:[NSString stringWithFormat:@"%zd",minute%10] forState:UIControlStateNormal];
    [_mFirst setTitle:[NSString stringWithFormat:@"%zd",second/10] forState:UIControlStateNormal];
    [_mSecond setTitle:[NSString stringWithFormat:@"%zd",second%10] forState:UIControlStateNormal];
}

@end

