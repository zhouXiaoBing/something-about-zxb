//
//  CartMainController.m
//  vitagou
//
//  Created by Mac on 2017/9/7.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

/**
 1.调取购物车接口时，验证登陆 user_token  未登录直接跳转到登陆页面
 2.接口参数就是token值一个
 http://www.vitagou.hk/mobile/app_query_joincart?user_token=2ab3d289e3e40ef2845bcff636f9eaef
 3.页面结构：collectionView 嵌套  
 
 */
#import "CartMainController.h"


@interface CartMainController ()



@end

@implementation CartMainController



@end
