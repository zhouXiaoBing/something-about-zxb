//
//  HXPhotoEditView.h
//  微博照片选择
//
//  Created by 洪欣 on 2017/6/30.
//  Copyright © 2017年 洪欣. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HXPhotoEditView : UIView

@end
