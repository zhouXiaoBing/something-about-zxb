//
//  GlobalDefine.h
//  vitagou
//
//  Created by 高坤 on 2017/7/12.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#ifndef GlobalDefine_h
#define GlobalDefine_h

#define Screen_Width [UIScreen mainScreen].bounds.size.width
#define Screen_Height [UIScreen mainScreen].bounds.size.height
#define Screen_Bounds [UIScreen mainScreen].bounds
#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;
#define THEME_COLOR WTKCOLOR(250, 98, 97, 1)
#endif /* GlobalDefine_h */
