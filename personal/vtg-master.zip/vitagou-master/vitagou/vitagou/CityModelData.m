//
//  CityModelData.m
//  vitagou
//
//  Created by 高坤 on 2017/9/5.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "CityModelData.h"

@implementation CityModelData


+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [Data class]};
}
@end
@implementation Data

+ (NSDictionary *)objectClassInArray{
    return @{@"_child" : [Child class]};
}

@end


@implementation Child

+ (NSDictionary *)objectClassInArray{
    return @{@"_child" : [Childs class]};
}

@end


@implementation Childs

@end
