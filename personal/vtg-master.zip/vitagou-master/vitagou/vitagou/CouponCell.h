//
//  CouponCell.h
//  vitagou
//
//  Created by 高坤 on 2017/8/7.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CouponData.h"
@class CouponTicket;
@interface CouponCell : UITableViewCell
@property (nonatomic,strong)CouponTicket *data;
@property (nonatomic)NSInteger status;
@end
