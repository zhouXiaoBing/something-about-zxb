//
//  LogisticCell.h
//  vitagou
//
//  Created by 高坤 on 2017/8/23.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LogisticData.h"
@class LogisticData;
@interface LogisticCell : UITableViewCell
@property (nonatomic,strong)LogisticData *data;
@end
