//
//  AddressView.m
//  vitagou
//
//  Created by 高坤 on 2017/9/4.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "AddressView.h"
#import "VTGConstants.h"
#import "Color.h"
@implementation AddressView

- (instancetype)init {
    self = [super init];
    if (self){
        [self initView];
    }
    return self;
}
-(void) initView{
    UILabel * name=[[UILabel alloc]init];
    name.textColor = GKCOLOR(49, 49, 49, 1);
    name.text=vtgReciverName;
    name.font      = [UIFont systemFontOfSize:13];
    [self addSubview:name];
    [name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(15);
        make.left.equalTo(self).offset(10);
    }];
    _addressNameField=[[UITextField alloc]init];
    [self addSubview:_addressNameField];
    _addressNameField.borderStyle=UITextBorderStyleNone;
    _addressNameField.leftViewMode = UITextFieldViewModeAlways;
    _addressNameField.placeholder=vtgAddressNameHint;
    _addressNameField.textColor = [UIColor darkGrayColor];
    _addressNameField.font = [UIFont systemFontOfSize:13];
    [_addressNameField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(name);
        make.left.equalTo(name.mas_right).offset(10);
        make.height.mas_equalTo(30);
        make.width.mas_equalTo(200);
    }];
    UIView *line            = [[UIView alloc]init];
    line.backgroundColor    = GKCOLOR(199, 199, 199, 1);
    [self addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self);
        make.right.equalTo(self);
        make.top.equalTo(name.mas_bottom).offset(15);
        make.height.mas_equalTo(0.5);
    }];
    UILabel * phone=[[UILabel alloc]init];
    phone.textColor = GKCOLOR(49, 49, 49, 1);
    phone.text=vtgAddressPhone;
    phone.font      = [UIFont systemFontOfSize:13];
    [self addSubview:phone];
    [phone mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(line.mas_bottom).offset(15);
        make.left.equalTo(self).offset(10);
    }];
    _phoneField=[[UITextField alloc]init];
    [self addSubview:_phoneField];
    _phoneField.borderStyle=UITextBorderStyleNone;
    _phoneField.leftViewMode = UITextFieldViewModeAlways;
    _phoneField.placeholder=vtgAddressPhoneHint;
    _phoneField.textColor = [UIColor darkGrayColor];
    _phoneField.font = [UIFont systemFontOfSize:13];
    [_phoneField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(phone);
        make.left.equalTo(phone.mas_right).offset(15);
        make.height.mas_equalTo(30);
        make.width.mas_equalTo(200);
    }];
    UIView *lineSecond            = [[UIView alloc]init];
    lineSecond.backgroundColor    = GKCOLOR(199, 199, 199, 1);
    [self addSubview:lineSecond];
    [lineSecond mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self);
        make.right.equalTo(self);
        make.top.equalTo(phone.mas_bottom).offset(15);
        make.height.mas_equalTo(0.5);
    }];
    UILabel * idCard=[[UILabel alloc]init];
    idCard.textColor = GKCOLOR(49, 49, 49, 1);
    idCard.text=vtgCard;
    idCard.font      = [UIFont systemFontOfSize:13];
    [self addSubview:idCard];
    [idCard mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(lineSecond.mas_bottom).offset(15);
        make.left.equalTo(self).offset(10);
    }];
    _idCardField=[[UITextField alloc]init];
    [self addSubview:_idCardField];
    _idCardField.borderStyle=UITextBorderStyleNone;
    _idCardField.leftViewMode = UITextFieldViewModeAlways;
    _idCardField.placeholder=vtgIdCardIsNil;
    _idCardField.textColor = [UIColor darkGrayColor];
    _idCardField.font = [UIFont systemFontOfSize:13];
    [_idCardField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(idCard);
        make.left.equalTo(idCard.mas_right).offset(15);
        make.height.mas_equalTo(30);
        make.width.mas_equalTo(200);
    }];
    UIView *explain            = [[UIView alloc]init];
    explain.backgroundColor    = GKCOLOR(234, 234, 234, 1);
    [self addSubview:explain];
    [explain mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self);
        make.right.equalTo(self);
        make.top.equalTo(idCard.mas_bottom).offset(15);
        make.height.mas_equalTo(35);
    }];
    UILabel * tvExplain=[[UILabel alloc]init];
    tvExplain.textColor = [UIColor redColor];
    tvExplain.text=vtgAddressExplain;
    tvExplain.font      = [UIFont systemFontOfSize:13];
    [explain addSubview:tvExplain];
    [tvExplain mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(explain).offset(5);
        make.bottom.equalTo(explain).offset(-5);
        make.centerX.equalTo(explain);
    }];

    UILabel * address=[[UILabel alloc]init];
    address.textColor = GKCOLOR(49, 49, 49, 1);
    address.text=vtgLoaction;
    address.font      = [UIFont systemFontOfSize:13];
    [self addSubview:address];
    [address mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(explain.mas_bottom).offset(15);
        make.left.equalTo(self).offset(10);
    }];
    _addressField=[[UILabel alloc]init];
    [self addSubview:_addressField];
    _addressField.text=vtgLoactionHint;
    _addressField.userInteractionEnabled=YES;
    UITapGestureRecognizer *labelTapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(labelTouchUpInside)];
    
    [_addressField addGestureRecognizer:labelTapGestureRecognizer];
    _addressField.textColor = [UIColor darkGrayColor];
    _addressField.font = [UIFont systemFontOfSize:13];
    [_addressField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(address);
        make.left.equalTo(phone.mas_right).offset(15);
        make.height.mas_equalTo(30);
        make.width.mas_equalTo(200);
    }];
    UIView *lineThird           = [[UIView alloc]init];
    lineThird.backgroundColor    = GKCOLOR(199, 199, 199, 1);
    [self addSubview:lineThird];
    [lineThird mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self);
        make.right.equalTo(self);
        make.top.equalTo(address.mas_bottom).offset(15);
        make.height.mas_equalTo(0.5);
    }];
    UILabel * explicitLocation=[[UILabel alloc]init];
    explicitLocation.textColor = GKCOLOR(49, 49, 49, 1);
    explicitLocation.text=vtgExplicitLoaction;
    explicitLocation.font      = [UIFont systemFontOfSize:13];
    [self addSubview:explicitLocation];
    [explicitLocation mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(lineThird.mas_bottom).offset(15);
        make.left.equalTo(self).offset(10);
    }];
    _locationField=[[UITextField alloc]init];
    [self addSubview:_locationField];
    _locationField.borderStyle=UITextBorderStyleNone;
    _locationField.leftViewMode = UITextFieldViewModeAlways;
    _locationField.placeholder=vtgExplicitLoactionHint;
    _locationField.textColor = [UIColor darkGrayColor];
    _locationField.font = [UIFont systemFontOfSize:13];
    [_locationField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(explicitLocation);
        make.left.equalTo(explicitLocation.mas_right).offset(15);
        make.height.mas_equalTo(30);
        make.width.mas_equalTo(200);
    }];
    UIView *lineFour           = [[UIView alloc]init];
    lineFour.backgroundColor    = GKCOLOR(199, 199, 199, 1);
    [self addSubview:lineFour];
    [lineFour mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self);
        make.right.equalTo(self);
        make.top.equalTo(explicitLocation.mas_bottom).offset(15);
        make.height.mas_equalTo(0.5);
    }];

}
-(void)labelTouchUpInside{
    [self endEditing:YES];
    [self.delegate didClickButton];
}
@end
