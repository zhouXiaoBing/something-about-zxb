//
//  CouponData.m
//  vitagou
//
//  Created by 高坤 on 2017/8/7.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "CouponData.h"

@implementation CouponData
+(NSDictionary *)mj_objectClassInArray
{
    return @{
             @"ticket" : @"CouponTicket"
             };
}
@end
