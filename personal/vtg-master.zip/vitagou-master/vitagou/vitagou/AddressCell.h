//
//  AddressCell.h
//  vitagou
//
//  Created by 高坤 on 2017/7/31.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ExtraAddress.h"

@protocol MycellDelegate <NSObject>
-(void)didClickButton:(UIButton *)button;
-(void) clickButton:(UIButton *)button extraAddress:(ExtraAddress *)address;
@end
@class AddressManagerData;
@interface AddressCell : UITableViewCell
@property(nonatomic,strong)UIButton     *selectBtn;
@property(nonatomic,strong)UIButton     *editBtn;
@property (nonatomic,strong)AddressManagerData *data;
@property(nonatomic,assign) id<MycellDelegate> delegate;
@property (strong,nonatomic) UIViewController *owner;
@property(nonatomic) NSInteger deleteId;
@end
