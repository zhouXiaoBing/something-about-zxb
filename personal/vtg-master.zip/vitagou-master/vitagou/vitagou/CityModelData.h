//
//  CityModelData.h
//  vitagou
//
//  Created by 高坤 on 2017/9/5.
//  Copyright © 2017年 Vitagou. All rights reserved.
//
#import <Foundation/Foundation.h>

@class Data,Child,Childs;
@interface CityModelData : NSObject
/**
 *  省份模型数组
 */
@property (nonatomic, strong) NSArray<Data *> *data;

@end
@interface Data : NSObject
/**
 *  省份名字
 */
@property (nonatomic, copy) NSString *area_name;
@property (nonatomic, copy) NSString *area_id;
@property (nonatomic, copy) NSString *lev;
@property (nonatomic, copy) NSString *parent_id;
@property (nonatomic, copy) NSString *sort;
/**
 *  城市模型数组
 */
@property (nonatomic, strong) NSArray<Child *> *_child;

@end

@interface Child : NSObject
/**
 *  城市名字
 */
@property (nonatomic, copy) NSString *area_name;
@property (nonatomic, copy) NSString *area_id;
@property (nonatomic, copy) NSString *lev;
@property (nonatomic, copy) NSString *parent_id;
@property (nonatomic, copy) NSString *sort;
/**
 *  县级模型数组
 */
@property (nonatomic, strong) NSArray<Childs *> *_child;

@end

@interface Childs : NSObject
/**
 *  县级名字
 */
@property (nonatomic, copy) NSString *area_name;
@property (nonatomic, copy) NSString *area_id;
@property (nonatomic, copy) NSString *lev;
@property (nonatomic, copy) NSString *parent_id;
@property (nonatomic, copy) NSString *sort;

@end


