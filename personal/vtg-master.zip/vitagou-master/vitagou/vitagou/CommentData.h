//
//  CommentDa.h
//  vitagou
//
//  Created by 高坤 on 2017/8/2.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CommentImages.h"
@class CommentImages;
@interface CommentData : NSObject
@property (nonatomic,copy) NSString * comment_time;
@property (nonatomic,copy) NSString * contents;
@property (nonatomic,copy) NSString * goods_id;
@property (nonatomic, strong) NSMutableArray *images;
@property (nonatomic,copy) NSString * img;
@property (nonatomic,copy) NSString * name;
@property (nonatomic,copy) NSString * recontents;
@property (nonatomic,copy) NSString * status;
@property(nonatomic,assign)CGFloat cellHeight;
@end
