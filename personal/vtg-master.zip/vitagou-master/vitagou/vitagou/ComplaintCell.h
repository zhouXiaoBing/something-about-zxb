//
//  ComplaintCell.h
//  vitagou
//
//  Created by 高坤 on 2017/8/9.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ComplaintData.h"
@protocol MycellDelegate <NSObject>
-(void)didClickButton:(UIButton *)button;
@end
@interface ComplaintCell : UITableViewCell
@property (nonatomic,strong)ComplaintData *data;
@property(nonatomic,assign) id<MycellDelegate> delegate;
@end
