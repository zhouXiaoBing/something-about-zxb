//
//  CouponData.h
//  vitagou
//
//  Created by 高坤 on 2017/8/7.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CouponTicket.h"
@class CouponTicket;
@interface CouponData : NSObject
@property (nonatomic,copy) NSString * _not;
@property (nonatomic,copy) NSString * already;
@property (nonatomic,copy) NSString * overdue;
@property (nonatomic, strong) NSMutableArray *ticket;
@end
