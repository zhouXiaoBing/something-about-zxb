//
//  ExtraAddress.h
//  vitagou
//
//  Created by 高坤 on 2017/9/6.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ExtraAddress : NSObject
@property (nonatomic ,strong)NSString *address_id;
@property (nonatomic ,strong)NSString *accept_name;
@property (nonatomic ,strong)NSString *address;
@property (nonatomic ,strong)NSString *address_detail;
@property (nonatomic ,strong)NSString *mobile;
@property (nonatomic ,strong)NSString *Idcard;
@property (nonatomic ,strong)NSString *province;
@property (nonatomic ,strong)NSString *city;
@property (nonatomic ,strong)NSString *area;
@property (nonatomic ,strong)NSString *Idimg_zm;
@property (nonatomic ,strong)NSString *Idimg_fm;
@end
