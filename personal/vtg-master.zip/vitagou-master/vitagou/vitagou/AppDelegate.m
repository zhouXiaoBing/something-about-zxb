//
//  AppDelegate.m 首先理解这个是一个类似Android里面application的类是一直运行的 不管在哪个页面都会有她的存在
//  vitagou
//
//  Created by Mac on 2017/3/23.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "AppDelegate.h"
#import "GuideViewController.h"
#import "MyViewController.h"
#import <MeiQiaSDK/MQManager.h>
#import "VTGConstants.h"
#import "ThirdPartyLoginManager.h"
#import <AlipaySDK/AlipaySDK.h>
#import "MyOrderController.h"
#import "orderConfirmController.h"
#import "WXApi.h"

@interface AppDelegate ()<WXApiDelegate>
//这里连线到MainWindow.xib


@end

@implementation AppDelegate



- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
     NSLog(@"didFinishLaunchingWithOptions被执行");
    [self addNotification];
    [self buildKeyWindow];//是否执行轮播图
    
    /* 打开调试日志 */
    [[UMSocialManager defaultManager] openLog:YES];
    
    /* 设置友盟appkey */
    [[UMSocialManager defaultManager] setUmSocialAppkey:@"59db27598f4a9d55ab000029"];
    
    [self configUSharePlatforms];
    
    [self confitUShareSettings];
    
    //iOS11 解决SafeArea的问题，同时能解决pop时上级页面scrollView抖动的问题
    if (@available(iOS 11, *)) {
        //解决iOS11，仅实现heightForHeaderInSection，没有实现viewForHeaderInSection方法时,section间距大的问题
        [UITableView appearance].estimatedRowHeight = 0;
        [UITableView appearance].estimatedSectionHeaderHeight = 0;
        [UITableView appearance].estimatedSectionFooterHeight = 0;
        [UIScrollView appearance].contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        [UICollectionView appearance].contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    
    [MQManager initWithAppkey:vtgMeiQiaId completion:^(NSString *clientId, NSError *error) {
    }];
    
    
    SDWebImageDownloader *manager = [SDWebImageManager sharedManager].imageDownloader;
    [manager setValue:@"http://www.vitagou.hk/" forHTTPHeaderField:@"Referer"];
    
    return YES;
}

- (void)confitUShareSettings
{
    /*
     * 打开图片水印
     */
    //[UMSocialGlobal shareInstance].isUsingWaterMark = YES;
    
    /*
     * 关闭强制验证https，可允许http图片分享，但需要在info.plist设置安全域名
     <key>NSAppTransportSecurity</key>
     <dict>
     <key>NSAllowsArbitraryLoads</key>
     <true/>
     </dict>
     */
    //[UMSocialGlobal shareInstance].isUsingHttpsWhenShareContent = NO;
    
}

- (void)configUSharePlatforms
{
    /*
     设置微信的appKey和appSecret
     [微信平台从U-Share 4/5升级说明]http://dev.umeng.com/social/ios/%E8%BF%9B%E9%98%B6%E6%96%87%E6%A1%A3#1_1
     */
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_WechatSession appKey:@"wx15b01dbdd25b34bb" appSecret:@"695483d609d637f926834b4fb311e25c" redirectURL:nil];
    /*
     * 移除相应平台的分享，如微信收藏
     */
    //[[UMSocialManager defaultManager] removePlatformProviderWithPlatformTypes:@[@(UMSocialPlatformType_WechatFavorite)]];
    
    /* 设置分享到QQ互联的appID
     * U-Share SDK为了兼容大部分平台命名，统一用appKey和appSecret进行参数设置，而QQ平台仅需将appID作为U-Share的appKey参数传进即可。
     100424468.no permission of union id
     [QQ/QZone平台集成说明]http://dev.umeng.com/social/ios/%E8%BF%9B%E9%98%B6%E6%96%87%E6%A1%A3#1_3
     */
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_QQ appKey:@"1106422626"/*设置QQ平台的appID*/  appSecret:nil redirectURL:nil];
    
   
    
}


- (void)buildKeyWindow {
    
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    [self.window makeKeyAndVisible];
    NSString *isFirstOpenApp = [[NSUserDefaults standardUserDefaults] objectForKey:IsFristOpenApp];
    if (isFirstOpenApp == nil) {
        self.window.rootViewController = [GuideViewController new];
        [[NSUserDefaults standardUserDefaults] setObject:IsFristOpenApp forKey:IsFristOpenApp];
    }else{
        [self loadAdRootController];
    }
}




- (void)addNotification {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showMainTabarController) name:GuideViewControllerDidFinish object:nil];
}
- (void)setRootViewController{
    //注销登录调用这个方法
 self.window.rootViewController = [MyViewController new];

}
- (void)loadAdRootController {
    //self.window.rootViewController = [MainTabBarController new];
    self.window.rootViewController = [MyViewController new];
}

- (void)showMainTabarController {
    self.window.rootViewController = [MyViewController new];
}
/*
 //据说这是一个已经被放弃的方法  还有这个是mac应用时会使用的方法
 - (void)applicationDidFinishLaunching:(UIApplication *)application{
     NSLog(@"applicationDidFinishLaunching被执行");
//    _window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen]
    self.window = [[UIWindow alloc] init];
    // decide which kind of content we need based on the device idiom,
    // when we load the proper nib, the "ContentController" class will take it from here
    //
    NSString *nibTitle = @"PhoneContent";
    NSLog(@"dd");
//    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
//    {
//        nibTitle = @"PhoneContent";
//    }
    [[NSBundle mainBundle] loadNibNamed:nibTitle owner:self options:nil];
    [self.window makeKeyAndVisible];
    self.window.frame = [[UIScreen mainScreen]bounds];
}

*/
- (void)applicationWillResignActive:(UIApplication *)application {
    NSLog(@"applicationWillResignActive被执行");
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    NSLog(@"applicationDidEnterBackground被执行");
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
     NSLog(@"applicationWillEnterForeground被执行");
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
     NSLog(@"applicationDidBecomeActive被执行");
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    NSLog(@"applicationWillTerminate被执行");
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    // Saves changes in the application's managed object context before the application terminates.
    [self saveContext];
}


#pragma mark - Core Data stack

@synthesize persistentContainer = _persistentContainer;

- (NSPersistentContainer *)persistentContainer {//原代码中注册相关
    // The persistent container for the application. This implementation creates and returns a container, having loaded the store for the application to it.
    @synchronized (self) {
        if (_persistentContainer == nil) {
            _persistentContainer = [[NSPersistentContainer alloc] initWithName:@"vitagou"];
            [_persistentContainer loadPersistentStoresWithCompletionHandler:^(NSPersistentStoreDescription *storeDescription, NSError *error) {
                if (error != nil) {
                    // Replace this implementation with code to handle the error appropriately.
                    // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                    
                    /*
                     Typical reasons for an error here include:
                     * The parent directory does not exist, cannot be created, or disallows writing.
                     * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                     * The device is out of space.
                     * The store could not be migrated to the current model version.
                     Check the error message to determine what the actual problem was.
                    */
                    NSLog(@"Unresolved error %@, %@", error, error.userInfo);
                    abort();
                }
            }];
        }
    }
    
    return _persistentContainer;
}

#pragma mark - Core Data Saving support

- (void)saveContext {
    NSManagedObjectContext *context = self.persistentContainer.viewContext;
    NSError *error = nil;
    if ([context hasChanges] && ![context save:&error]) {
        // Replace this implementation with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        NSLog(@"Unresolved error %@, %@", error, error.userInfo);
        abort();
    }
}
// iOS9 以上用这个方法接收
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString *,id> *)options
{
    NSDictionary * dic = options;
    NSLog(@"%@", dic);
    if ([options[UIApplicationOpenURLOptionsSourceApplicationKey] isEqualToString:@"com.sina.weibo"]) {
        NSLog(@"新浪微博~");
        
        return [WeiboSDK handleOpenURL:url delegate:[ThirdPartyLoginManager shareThirdPartyLoginManager]];
        
    }else if ([options[UIApplicationOpenURLOptionsSourceApplicationKey] isEqualToString:@"com.tencent.xin"]){
        NSLog(@"com.tencent.xin~url %@",url.host);
        if ([url.host isEqualToString:@"oauth"]) {
            return [WXApi handleOpenURL:url delegate:[ThirdPartyLoginManager shareThirdPartyLoginManager]];
        }
        if ([url.host isEqualToString:@"pay"]) {
             [AJNotification postNotificationName:OrderConfirmGotoMyorder object:nil];
            return YES;
        }
        
        
    }else if ([options[UIApplicationOpenURLOptionsSourceApplicationKey] isEqualToString:@"com.tencent.mqq"]){
        
        //        [WTThirdPartyLoginManager didReceiveTencentUrl:url];
        return [TencentOAuth HandleOpenURL:url];
    }
    
    if ([url.host isEqualToString:@"safepay"]) {
        //跳转支付宝钱包进行支付，处理支付结果
        [[AlipaySDK defaultService] processOrderWithPaymentResult:url standbyCallback:^(NSDictionary *resultDic) {
            NSLog(@"resultdddddd = %@",resultDic);
            
            [AJNotification postNotificationName:OrderConfirmGotoMyorder object:nil];

        }];
    }
    return YES;
}
// iOS9 以下用这个方法接收
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    NSLog(@"%@",url);
    
    
    if ([sourceApplication isEqualToString:@"com.sina.weibo"]) {
        
        return [WeiboSDK handleOpenURL:url delegate:[ThirdPartyLoginManager shareThirdPartyLoginManager]];
        
    }else if ([sourceApplication isEqualToString:@"com.tencent.xin"]){
        
        return [WXApi handleOpenURL:url delegate:[ThirdPartyLoginManager shareThirdPartyLoginManager]];
        
    }else if ([sourceApplication isEqualToString:@"com.tencent.mqq"]){
        
        //        [WTShareManager didReceiveTencentUrl:url];
        return [TencentOAuth HandleOpenURL:url];
    }
    
    if ([url.host isEqualToString:@"safepay"]) {
        //跳转支付宝钱包进行支付，处理支付结果
        [[AlipaySDK defaultService] processOrderWithPaymentResult:url standbyCallback:^(NSDictionary *resultDic) {
            NSLog(@"result = %@",resultDic);
            //支付宝动作后跳转到订单列表
            
        }];
    }
    
    
    return YES;
}

//-------


- (void)didClick {
    
}

- (void)toMyOrder {
    
}

@end
