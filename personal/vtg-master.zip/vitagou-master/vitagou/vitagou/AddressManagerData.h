//
//  AddressManagerData.h
//  vitagou
//
//  Created by 高坤 on 2017/7/31.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AddressManagerData : NSObject
@property (nonatomic,copy) NSString * accept_name;
@property (nonatomic,copy) NSString * add_time;
@property (nonatomic,copy) NSString * address;
@property (nonatomic,copy) NSString * address_id;
@property (nonatomic,copy) NSString * area;
@property (nonatomic,copy) NSString * area_val;
@property (nonatomic,copy) NSString * city;
@property (nonatomic,copy) NSString * city_val;
@property (nonatomic,copy) NSString * country;
@property (nonatomic,copy) NSString * id_status;
@property (nonatomic,copy) NSString * Idcard;
@property (nonatomic,copy) NSString * is_default;
@property (nonatomic,copy) NSString * mobile;
@property (nonatomic,copy) NSString * province;
@property (nonatomic,copy) NSString * province_val;
@property (nonatomic,copy) NSString * telphone;
@property (nonatomic,copy) NSString * user_id;
@property (nonatomic,copy) NSString * Idimg_zm;
@property (nonatomic,copy) NSString * Idimg_fm;

@end
