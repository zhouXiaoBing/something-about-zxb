//
//  DCDetailShufflingHeadView.h
//  CDDMall
//
//  Created by apple on 2017/6/21.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DCDetailShufflingHeadView : UICollectionReusableView

/** 轮播数组 */
@property (nonatomic, copy) NSArray *shufflingArray;

@end
