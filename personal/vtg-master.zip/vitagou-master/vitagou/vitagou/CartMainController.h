//
//  CartMainController.h
//  vitagou
//
//  Created by Mac on 2017/9/7.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "zxb_cart_data.h"
@interface CartMainController : UIViewController

@property(nonatomic, strong) zxb_cart_data *cartData;

@end
