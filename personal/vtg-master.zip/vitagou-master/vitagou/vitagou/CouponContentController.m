//
//  CouponContentController.m
//  vitagou
//
//  Created by 高坤 on 2017/8/7.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "CouponContentController.h"
#import "CouponCell.h"
#import "VTGConstants.h"
#import "CouponCell.h"
#import "CouponBean.h"
@interface CouponContentController ()<UITableViewDelegate,UITableViewDataSource>
@property (strong , nonatomic)UITableView *tableView;
@property (nonatomic ,strong)NSMutableArray *dataSource;
@end
static NSString *const DCSettingCellID = @"coupon";
@implementation CouponContentController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setTintColor:[UIColor blackColor]];
    [self loadData];
    
}
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.frame = CGRectMake(0, 0,self.view.bounds.size.width,self.view.bounds.size.height-60);
        _tableView.backgroundColor=[UIColor whiteColor];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        
        [self.view addSubview:_tableView];
        
        [_tableView registerClass:[CouponCell class] forCellReuseIdentifier:DCSettingCellID];
    }
    return _tableView;
}

- (void)loadData{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:vtgTEXTORHTML];
    NSString *token=[[NSUserDefaults standardUserDefaults] objectForKey:vtgParams_token];
    NSString *type;
    if(_status==101){
        type=vtgParams_NotUser;
    }else if(_status==102){
        type=vtgParams_IsUser;
    }
    else{
        type=vtgParams_Exprie;
    }
    NSDictionary *parameters = @{vtgParams_token:token,vtgParams_Type:type};
    [manager POST:COUNPONS parameters:parameters
          success:^(AFHTTPRequestOperation *operation,id responseObject) {

                  
            CouponBean *couponBean = [CouponBean mj_objectWithKeyValues:responseObject];
            self.dataSource =couponBean.data.ticket;
            [self.tableView reloadData ];
          }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
              NSLog(@"Error: %@", error);
          }];
    
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.dataSource.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CouponCell *cell = [tableView dequeueReusableCellWithIdentifier:DCSettingCellID forIndexPath:indexPath];
    cell.data = self.dataSource[indexPath.row];
    cell.status=_status;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 110;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 5;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
