//
//  GGActionSheet.h
//  vitagou
//
//  Created by 高坤 on 2017/8/24.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol GGActionSheetDelegate<NSObject>
-(void)GGActionSheetClickWithIndex:(int)index;
@end
@interface GGActionSheet : UIView
@property(nonatomic,weak) id <GGActionSheetDelegate> delegate;
//默认取消按钮颜色
@property(nonatomic,strong) UIColor *cancelDefaultColor;
//默认选项按钮颜色
@property(nonatomic,strong) UIColor *optionDefaultColor;




//创建标题形式ActionSheet
+(instancetype)ActionSheetWithTitleArray:(NSArray *)titleArray  andTitleColorArray:(NSArray *)colors delegate:(id<GGActionSheetDelegate>)delegate;

//创建图片形式ActionSheet
+(instancetype)ActionSheetWithImageArray:(NSArray *)imgArray delegate:(id<GGActionSheetDelegate>)delegate;

//显示ActionSheet
-(void)showGGActionSheet;



@end
