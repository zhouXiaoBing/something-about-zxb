//
//  QQLoginUser.h
//  vitagou
//
//  Created by 高坤 on 2017/9/30.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LoginUser : NSObject
@property (nonatomic, strong) NSString *username;
@property (nonatomic, strong) NSString *password;
@end
