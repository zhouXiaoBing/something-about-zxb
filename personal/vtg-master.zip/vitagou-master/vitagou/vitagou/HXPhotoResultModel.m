//
//  HXPhotoResultModel.m
//  微博照片选择
//
//  Created by 洪欣 on 2017/8/12.
//  Copyright © 2017年 洪欣. All rights reserved.
//

#import "HXPhotoResultModel.h"

@implementation HXPhotoResultModel

@end
