//
//  CommentCell.h
//  vitagou
//
//  Created by 高坤 on 2017/8/2.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommentData.h"
@class CommentData;
@interface CommentCell : UITableViewCell
@property (nonatomic,strong)CommentData *data;
@end
