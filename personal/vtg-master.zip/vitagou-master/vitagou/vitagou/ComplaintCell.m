//
//  ComplaintCell.m
//  vitagou
//
//  Created by 高坤 on 2017/8/9.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "ComplaintCell.h"
#import "VTGConstants.h"
#import "Color.h"
#import "ComplaintData.h"
@interface ComplaintCell()
@property(nonatomic,strong) ComplaintData *complaintData;
@property(nonatomic,strong) UILabel *orderTime;
@property(nonatomic,strong) UILabel *number;
@property(nonatomic,strong) UILabel *refundId;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic,strong) UIImageView *goodImg;
@property(nonatomic,strong) UILabel *goodsName;
@property(nonatomic,strong) UILabel *goodsPrice;
@property(nonatomic,strong) UIButton *cancleButton;
@end
@implementation ComplaintCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
        [self initView];
    }
    return self;
}
-(void)setData:(ComplaintData *)data{
    _complaintData=data;
    _orderTime.text=data.time;
    _number.text=data.order_no;
    _refundId.text=data.refund_id;
    _cancleButton.hidden=YES;
    // pay_status 0:待审核 1：拒绝 2：已退款 3：同意 4:售后退款中 5：投诉待审核 6：投诉拒绝 7：投诉通过
    if([data.pay_status isEqualToString:@"0"]){
        _status.text=vtgRefundStatus;
        _cancleButton.hidden=NO;
    }else if([data.pay_status isEqualToString:@"1"]){
        _status.text=vtgRefundStatusSecond;
    }else if([data.pay_status isEqualToString:@"2"]){
        _status.text=vtgRefundSuccess;
    }else if([data.pay_status isEqualToString:@"3"]){
        _status.text=vtgRefundStatusThird;
    }else if([data.pay_status isEqualToString:@"4"]){
      _status.text=vtgRefundStatusFourth;
    }else if([data.pay_status isEqualToString:@"5"]){
        _status.text=vtgRefundStatusFifth;
    }else if([data.pay_status isEqualToString:@"6"]){
        _status.text=vtgRefundStatusSixth;
    }else if([data.pay_status isEqualToString:@"7"]){
        _status.text=vtgRefundStatusSeventh;
    }
    NSLog(@"%@",[vtgUrl stringByAppendingString:data.img]);
     [_goodImg sd_setImageWithURL: [NSURL URLWithString:[vtgUrl stringByAppendingString:data.img]]placeholderImage:[UIImage imageNamed:@"default_image"]];
    _goodsName.text=data.name;
    _goodsPrice.text=[@"￥" stringByAppendingString:data.sell_price];
}
- (void)initView
{
    self.selectionStyle     = UITableViewCellSelectionStyleNone;
    _orderTime=[[UILabel alloc]init];
    _orderTime.textColor = GKCOLOR(150 , 150, 150, 1);
    _orderTime.font      = [UIFont systemFontOfSize:12];
    [self addSubview:_orderTime];
    [_orderTime mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(10);
        make.left.equalTo(self).offset(10);
    }];
    
    UILabel *orderNumber=[[UILabel alloc]init];
    orderNumber.textColor = GKCOLOR(150 , 150, 150, 1);
    orderNumber.text=vtgOrderNumber;
    orderNumber.font      = [UIFont systemFontOfSize:12];
    [self addSubview:orderNumber];
    [orderNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_orderTime.mas_bottom).offset(5);
        make.left.equalTo(self).offset(10);
    }];
    
    _number=[[UILabel alloc]init];
    _number.textColor = GKCOLOR(150 , 150, 150, 1);
    _number.font      = [UIFont systemFontOfSize:12];
    [self addSubview:_number];
    [_number mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(orderNumber);
        make.left.equalTo(orderNumber.mas_right).offset(5);
    }];
    UILabel *refundNumber=[[UILabel alloc]init];
    refundNumber.textColor = GKCOLOR(150 , 150, 150, 1);
    refundNumber.text=vtgRefundId;
    refundNumber.font      = [UIFont systemFontOfSize:12];
    [self addSubview:refundNumber];
    [refundNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(orderNumber.mas_bottom).offset(5);
        make.left.equalTo(self).offset(10);
    }];
    _refundId=[[UILabel alloc]init];
    _refundId.textColor = GKCOLOR(150 , 150, 150, 1);
    _refundId.font      = [UIFont systemFontOfSize:12];
    [self addSubview:_refundId];
    [_refundId mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(refundNumber);
        make.left.equalTo(refundNumber.mas_right).offset(5);
    }];
    _status=[[UILabel alloc]init];
    _status.textColor = GKCOLOR(164, 53, 81, 1);
    _status.font      = [UIFont systemFontOfSize:12];
    [self addSubview:_status];
    [_status mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(orderNumber);
        make.right.equalTo(self).offset(-20);
    }];
    UIView *grayBG= [[UIView alloc]init];
    grayBG.backgroundColor=GKCOLOR(246, 246, 246, 1);
    [self addSubview:grayBG];
    [grayBG mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(@70);
        make.top.equalTo(refundNumber.mas_bottom).offset(10);
        make.left.equalTo(self);
        make.right.equalTo(self);
    }];
    _goodImg          = [[UIImageView alloc]init];
    [grayBG addSubview:_goodImg];
    [_goodImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(@70);
        make.width.equalTo(@70);
        make.top.equalTo(grayBG);
        make.left.equalTo(grayBG);
    }];
    _goodsName=[[UILabel alloc]init];
    _goodsName.textColor = GKCOLOR(49, 49, 49, 1);
    _goodsName.numberOfLines=2;
    _goodsName.font      = [UIFont systemFontOfSize:12];
    [grayBG addSubview:_goodsName];
    [_goodsName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(grayBG);
        make.right.equalTo(grayBG).offset(-60);
        make.left.equalTo(_goodImg.mas_right).offset(10);
    }];
    _goodsPrice=[[UILabel alloc]init];
    _goodsPrice.textColor = GKCOLOR(49, 49, 49, 1);
    _goodsPrice.font      = [UIFont systemFontOfSize:12];
    [grayBG addSubview:_goodsPrice];
    [_goodsPrice mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(grayBG).offset(-10);
        make.top.equalTo(grayBG).offset(25);
    }];
    UILabel *numbers=[[UILabel alloc]init];
    numbers.textColor = GKCOLOR(49, 49, 49, 1);
    numbers.font      = [UIFont systemFontOfSize:12];
    numbers.text=@"x1";
    [grayBG addSubview:numbers];
    [numbers mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(_goodsPrice);
        make.top.equalTo(_goodsPrice.mas_bottom).offset(10);
    }];

    self.cancleButton       = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.cancleButton setTitleColor:GKCOLOR(214, 30, 73, 1) forState:UIControlStateNormal];
    self.cancleButton.titleLabel.font   = [UIFont systemFontOfSize:13];
    self.cancleButton.layer.cornerRadius = 5;
    self.cancleButton.layer.masksToBounds = YES;
    self.cancleButton.layer.borderColor = GKCOLOR(214, 30, 73, 1).CGColor;
    self.cancleButton.layer.borderWidth = 0.7;
    [self.cancleButton setTitle:vtgCancleReply forState:UIControlStateNormal];
    [self addSubview:self.cancleButton];
    [self.cancleButton addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.cancleButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(grayBG.mas_bottom).offset(10);
        make.right.equalTo(self).offset(-10);
        make.height.mas_equalTo(25);
        make.width.mas_equalTo(60);
    }];
    UIView *line            = [[UIView alloc]init];
    line.backgroundColor    = GKCOLOR(199, 199, 199, 1);
    [self addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self);
        make.right.equalTo(self);
        make.bottom.equalTo(self).offset(-0.7);
        make.height.mas_equalTo(1);
    }];

}
-(void)btnClick:(UIButton *)btn{

   NSInteger _deleteId=[_complaintData.refund_id integerValue];
    btn.tag=_deleteId;
    [self.delegate didClickButton:btn];

}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
