//
//  DCCommentHeaderCell.h
//  CDDMall
//
//  Created by apple on 2017/6/27.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DCCommentHeaderCell : UICollectionViewCell

/* 评论数量 */
@property (copy , nonatomic)NSString *comNum;

/* 好评比 */
@property (copy , nonatomic)NSString *wellPer;

@end
