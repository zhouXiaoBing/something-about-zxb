//
//  HXPhotoConst.m
//  微博照片选择
//
//  Created by 洪欣 on 17/3/17.
//  Copyright © 2017年 洪欣. All rights reserved.
//

#import <UIKit/UIKit.h>

NSString *const HXPhotoCameraFocusing = @"camera_ Focusing@2x.png";
