//
//  CommentData.h
//  vitagou
//
//  Created by 高坤 on 2017/7/17.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CollectionData : NSObject
@property (nonatomic,copy) NSString * goods_id;
@property (nonatomic,copy) NSString * img;
@property (nonatomic,copy) NSString * is_del;
@property (nonatomic,copy) NSString * market_price;
@property (nonatomic,copy) NSString * name;
@property (nonatomic,copy) NSString * rid;
@property (nonatomic,copy) NSString * sell_price;
@end
