//
//  CommentCell.m
//  vitagou
//
//  Created by 高坤 on 2017/8/2.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "CommentCell.h"
#import "CommentData.h"
#import "Color.h"
#import "VTGConstants.h"
#import "UiView+HD_Extension.h"
#import "SDPhotoBrowser.h"
#define KMainWidth [UIScreen mainScreen].bounds.size.width
#define KMainHeight  [UIScreen mainScreen].bounds.size.height
@interface CommentCell ()<SDPhotoBrowserDelegate>
@property(nonatomic,strong) UILabel *titleLabel;
@property(nonatomic,strong) UILabel *contentLabel;
@property(nonatomic,strong) UILabel *timeLabel;
@property(nonatomic,strong) UIImageView *headImage;
@property(nonatomic,strong)UIImageView *backimage;
@property(nonatomic,strong) UIView *photoView;
@property(nonatomic,strong)NSMutableArray *imgViewArray;
@property(nonatomic,strong) CommentData *commentData;
@end
@implementation CommentCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
        [self initView];
    }
    return self;
}
-(void)setData:(CommentData *)data{
    self.commentData=data;
    self.titleLabel.text=data.name;
    [self.headImage sd_setImageWithURL: [NSURL URLWithString:[vtgUrl stringByAppendingString:data.img]]placeholderImage:[UIImage imageNamed:@"default_image"]];
    self.contentLabel.text=data.contents;
    self.timeLabel.text=data.comment_time;
    CommentImages *img=[[CommentImages alloc]init];
    img=data.images[0];
    NSString *imgStr=img.img;
    if(![imgStr isEqualToString:@""]){
        [self photoList:data];
    }
}
- (void)initView
{
    self.selectionStyle     = UITableViewCellSelectionStyleNone;
    self.headImage          = [[UIImageView alloc]init];
    [self addSubview:self.headImage];
    [self.headImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(10);
        make.left.equalTo(self).offset(10);
        make.width.mas_equalTo(30);
        make.height.mas_equalTo(30);
    }];
    UILabel * isComment       = [[UILabel alloc]init];
    isComment.textColor = [UIColor redColor];
    isComment.font      = [UIFont systemFontOfSize:12];
    isComment.text=vtgIsComment;
    [self addSubview:isComment];
    [isComment mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_headImage);
        make.left.equalTo(self.headImage.mas_right).offset(10);
    }];
    self.titleLabel       = [[UILabel alloc]init];
    _titleLabel.textColor = GKCOLOR(80, 80, 80, 1);
    _titleLabel.font      = [UIFont systemFontOfSize:12];
    [self addSubview:self.titleLabel];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_headImage);
        make.left.equalTo(isComment.mas_right).offset(10);
        make.right.equalTo(self).offset(-10);
    }];
    self.contentLabel       = [[UILabel alloc]init];
    _contentLabel.textColor = GKCOLOR(80, 80, 80, 1);
    _contentLabel.font      = [UIFont systemFontOfSize:12];
    [self addSubview:_contentLabel];
    [_contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_headImage.mas_bottom).offset(20);
        make.left.equalTo(self).offset(10);
    }];
    self.timeLabel      = [[UILabel alloc]init];
    _timeLabel.textColor = GKCOLOR(80, 80, 80, 1);
    _timeLabel.font      = [UIFont systemFontOfSize:10];
    [self addSubview:_timeLabel];
    [_timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_contentLabel.mas_bottom).offset(10);
        make.left.equalTo(self).offset(10);
    }];
    
}
-(UIImageView *)backimage{
    
    if (!_backimage) {
        
        UIImageView *backImage = [[UIImageView alloc]init];
        backImage.frame = CGRectMake(0, 100 ,KMainWidth- 10,0);
        backImage.backgroundColor =  [UIColor whiteColor];
        backImage.userInteractionEnabled = YES;
        self.backimage = backImage;
    }
    return _backimage;
    
}
-(void)photoList:(CommentData *)data{
    
    CGFloat imageX = 10;
    CGFloat imageWH = (KMainWidth - 40 ) / 3;
    for (int i = 0; i < data.images.count; i++) {
        NSInteger col = i / 3;
        NSInteger vol = i % 3;
        CommentImages *img=[[CommentImages alloc]init];
        img=data.images[i];
        NSString *imagestr=img.img;
        
        UIImageView * image = [[UIImageView alloc]init];
        image.frame = CGRectMake(vol*(imageWH +10) + 5 , col *(imageWH +10), imageWH, imageWH);
        [image sd_setImageWithURL: [NSURL URLWithString:[vtgUrl stringByAppendingString:imagestr]]placeholderImage:[UIImage imageNamed:@"default_image"]];
        [self.backimage addSubview:image];
        image.userInteractionEnabled = YES;
        image.tag = i;
        [image addGestureRecognizer:
         [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(imageClick:)]];
        [self addSubview:_backimage];
    }
    
    if (data.images.count <= 3) {
        self.backimage.HD_heigh = imageWH +0 *imageX;
    }else if( data.images.count > 3 && data.images.count <= 6){
        self.backimage.HD_heigh = 2 * imageWH + 1 *imageX;
    }else if( data.images.count > 6 && data.images.count <= 9){
        self.backimage.HD_heigh = 3 * imageWH + 2*imageX;
        
    }
    
}
- (NSURL *)photoBrowser:(SDPhotoBrowser *)browser highQualityImageURLForIndex:(NSInteger)index
{
    CommentImages *img=[[CommentImages alloc]init];
    img=_commentData.images[index];
    NSString *imagestr=img.img;
    NSURL *URL = [NSURL URLWithString:[vtgUrl stringByAppendingString:imagestr]];
    return URL;
}
-(void)imageClick:(UITapGestureRecognizer *)tap{
    
    UIView *imageView = tap.view;
    SDPhotoBrowser *browser = [[SDPhotoBrowser alloc] init];
    browser.currentImageIndex = imageView.tag;
    browser.sourceImagesContainerView = self;
    browser.imageCount = _commentData.images.count;
    browser.delegate = self;
    [browser show];

}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)prepareForReuse{
    [super prepareForReuse];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
