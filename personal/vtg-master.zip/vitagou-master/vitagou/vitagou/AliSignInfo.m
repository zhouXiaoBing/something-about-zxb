//
//  AliSignInfo.m
//  vitagou
//
//  Created by Mac on 2017/11/2.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AliSignInfo.h"

@implementation AliSignInfo

+(void)getAliSignInfo:(NSString *)user_token order_id:(NSString *)order_id success:(void (^)(AliSignInfo *))success failure:(void (^)(NSError *))failure{
 
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    
    NSDictionary *params = @{@"user_token":user_token,
                             @"orderId":order_id,
                             };
//    NSLog(@"user_token %@, order_id %@",user_token,order_id);
    NSLog(@"params %@",params);
    //VITAGOUURL@"mobile/app_get_alipay_params
    [manager POST:APP_GET_ALIPAY_PARAMS parameters:params success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSLog(@"responseObject: %@", responseObject);
       /* weixinPay *wxp = [weixinPay mj_objectWithKeyValues:responseObject];
        zxb_Result *result = wxp.result;
        weixinPayData *wxpd = wxp.data;
        success(result,wxpd);
        */
        AliSignInfo *asi = [AliSignInfo mj_objectWithKeyValues:responseObject];
        success(asi);
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        NSLog(@"Error: %@", error);
    }];
}
@end
