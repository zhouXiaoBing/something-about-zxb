//
//  CommentController.m
//  vitagou
//
//  Created by 高坤 on 2017/7/17.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "CollectionController.h"
#import "VTGConstants.h"
#import "CollectionData.h"
#import "StuffData.h"
#import "StuffBean.h"
#import "StuffList.h"
#import "CollectionListCell.h"
#import "Color.h"
#import "productMainController.h"
@interface CollectionController ()<UITableViewDelegate,UITableViewDataSource,MycellDelegate>
@property (strong , nonatomic)UITableView *tableView;
@property (nonatomic ,strong)NSMutableArray *dataSource;
@property(strong,nonatomic)StuffList *list;
@end
static NSString *const DCSettingCellID = @"CollectionListCell";
@implementation CollectionController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setTintColor:[UIColor blackColor]];

    if(_extraTag==101){
        self.title = @"我的收藏";
    }else{
        self.title=@"我的足迹";
    }
    [self loadData];
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.frame = CGRectMake(0, 0,self.view.bounds.size.width,self.view.bounds.size.height);
        _tableView.backgroundColor=[UIColor whiteColor];
        _tableView.delegate = self;
        _tableView.dataSource = self;

        [self.view addSubview:_tableView];
        
        [_tableView registerClass:[CollectionListCell class] forCellReuseIdentifier:DCSettingCellID];
          }
    return _tableView;
}

- (void)loadData{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:vtgTEXTORHTML];
    NSString *URL;
    if(_extraTag==101){
        URL=COMMENT_LIST;
    }else{
        URL=STUFF_LIST;
    }
    NSDictionary *parameters = @{vtgParams_token:[[NSUserDefaults standardUserDefaults] objectForKey:vtgParams_token]};
    [manager POST:URL parameters:parameters
          success:^(AFHTTPRequestOperation *operation,id responseObject) {
              NSLog(@"%@",responseObject);
              if(_extraTag==101){
                
               self.dataSource = [CollectionData mj_objectArrayWithKeyValuesArray:responseObject[vtgData]];
              }else{
                 
                  StuffBean *stuffBean = [StuffBean mj_objectWithKeyValues:responseObject];
                  self.dataSource =stuffBean.data.footprint;
              }
              [self.tableView reloadData ];
          }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
              NSLog(@"Error: %@", error);
          }];

    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.dataSource.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CollectionListCell *cell = [tableView dequeueReusableCellWithIdentifier:DCSettingCellID forIndexPath:indexPath];
    if(_extraTag==101){cell.data = self.dataSource[indexPath.row];
    }else{
        cell.stuffData=self.dataSource[indexPath.row];
    }
    cell.delegate=self;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    productMainController *product;
    if(_extraTag==101){
        CollectionData *collectionData= self.dataSource[indexPath.row];
        product=[[productMainController alloc]initWithProductId:collectionData.goods_id];
    }else{
        StuffData *stuffData=self.dataSource[indexPath.row];
         product=[[productMainController alloc]initWithProductId:stuffData.goods_id];
    }
    [self.navigationController pushViewController:product animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 100;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.0001;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

-(void)didClickButton:(UIButton *)button
{
    
   UIAlertController *uiAlert =[UIAlertController alertControllerWithTitle:vtgDeleteContent message:vtgIsDelete preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okButton = [UIAlertAction actionWithTitle:vtgSure style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *goodId= [NSString stringWithFormat:@"%ld",button.tag];
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:vtgTEXTORHTML];
        NSString *URL;
        NSString *userToken=[[NSUserDefaults standardUserDefaults] objectForKey:vtgParams_token];
        NSDictionary *parameters;
        if(_extraTag==101){
            URL=COMMENT_DELETE;
            parameters = @{vtgParams_token:userToken,vtgParams_rid:goodId};
        }
        else{
            URL=STUFF_DELETE;
            parameters = @{vtgParams_token:userToken,vtgParams_goodsId:goodId};
        }
        [manager POST:URL parameters:parameters
              success:^(AFHTTPRequestOperation *operation,id responseObject) {
                  NSLog(@"%@",responseObject);
                  [self loadData];
              }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
                  NSLog(@"Error: %@", error);
              }];

    }];
    UIAlertAction *cancelButton = [UIAlertAction actionWithTitle:vtgCancel style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
    }];
    [uiAlert addAction:okButton];
    [uiAlert addAction:cancelButton];
    [self presentViewController:uiAlert animated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
-(void)dealloc{
    [[[SDWebImageManager sharedManager] imageCache] clearMemory];
    [[[SDWebImageManager sharedManager] imageCache] clearDisk];
}

@end
