//
//  ComplaintController.m
//  vitagou
//
//  Created by 高坤 on 2017/8/9.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "ComplaintController.h"
#import "VTGConstants.h"
#import "ComplaintCell.h"
#import "ComplaintData.h"
#import "RefundServiceViewController.h"
@class ComplaintData;
@interface ComplaintController ()<UITableViewDelegate,UITableViewDataSource,MycellDelegate,RefundServiceDelegate>
@property (strong , nonatomic)UITableView *tableView;
@property (nonatomic ,strong)NSMutableArray *dataSource;
@property (nonatomic ,strong)ComplaintData *complaintData;
@end
static NSString *const DCSettingCellID = @"complaint";
@implementation ComplaintController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setTintColor:[UIColor blackColor]];
    if(_status==101){
        self.title=vtgRefund;
    }else{
        self.title=vtgComplaintManger;
    }
    [self loadData];
}
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.frame = CGRectMake(0, 0,self.view.bounds.size.width,self.view.bounds.size.height);
        _tableView.backgroundColor=[UIColor whiteColor];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        
        [self.view addSubview:_tableView];
        
        [_tableView registerClass:[ComplaintCell class] forCellReuseIdentifier:DCSettingCellID];
    }
    return _tableView;
}
- (void)loadData{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:vtgTEXTORHTML];
    NSString *token=[[NSUserDefaults standardUserDefaults] objectForKey:vtgParams_token];
    NSString *type;
    if(_status==101){
        type=@"0";
    }
    else{
        type=@"1";
    }
    NSDictionary *parameters = @{vtgParams_token:token,vtgParams_IsCp:type};
    [manager POST:REFUNDS parameters:parameters
          success:^(AFHTTPRequestOperation *operation,id responseObject) {
              
               self.dataSource = [ComplaintData mj_objectArrayWithKeyValuesArray:responseObject[vtgData]];
              [self.tableView reloadData ];
          }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
              NSLog(@"Error: %@", error);
          }];
    
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.dataSource.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ComplaintCell *cell = [tableView dequeueReusableCellWithIdentifier:DCSettingCellID forIndexPath:indexPath];
    cell.data = self.dataSource[indexPath.row];
    cell.delegate=self;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 190;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.1;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
-(void)didClickButton:(UIButton *)button
{
    UIAlertController *uiAlert =[UIAlertController alertControllerWithTitle:vtgCancleReply message:vtgIsCancleReply preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okButton = [UIAlertAction actionWithTitle:vtgSure style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *refundId= [NSString stringWithFormat:@"%ld",button.tag];
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:vtgTEXTORHTML];
        NSString *userToken=[[NSUserDefaults standardUserDefaults] objectForKey:vtgParams_token];
            NSDictionary *parameters = @{vtgParams_token:userToken,vtgParams_RefundId:refundId};
        [manager POST:DELETEREFUND parameters:parameters
              success:^(AFHTTPRequestOperation *operation,id responseObject) {
                  [self loadData];
              }failure:^(AFHTTPRequestOperation *operation,NSError *error) {
                  NSLog(@"Error: %@", error);
              }];

    }];
    UIAlertAction *cancelButton = [UIAlertAction actionWithTitle:vtgCancel style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
    }];
    [uiAlert addAction:okButton];
    [uiAlert addAction:cancelButton];
    [self presentViewController:uiAlert animated:YES completion:nil];

}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    _complaintData=self.dataSource[indexPath.row];
    RefundServiceViewController *view=[[RefundServiceViewController alloc]init];
    view.order_id=_complaintData.order_id;
    view.orderNumber=_complaintData.order_no;
    view.goodsId=_complaintData.goods_id;
    view.goodsArray=_complaintData.name;
    view.sellerName=_complaintData.seller_name;
    view.serllerId=_complaintData.seller_id;
    view.img=_complaintData.img;
    view.delegate=self;
    [self.navigationController pushViewController:view animated:YES];
}
-(void)breakSuccess{
    [self loadData];
}
-(void)dealloc{
    [[[SDWebImageManager sharedManager] imageCache] clearMemory];
    [[[SDWebImageManager sharedManager] imageCache] clearDisk];
}

@end
