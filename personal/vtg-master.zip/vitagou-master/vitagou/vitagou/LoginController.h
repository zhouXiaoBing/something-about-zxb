//
//  LoginController.h
//  vitagou
//
//  Created by 高坤 on 2017/7/25.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "GKBaseViewController.h"
@protocol LoginCellDelegate <NSObject>
-(void)didClickButton;
@end
@interface LoginController : GKBaseViewController
@property(nonatomic,assign) id<LoginCellDelegate> delegate;
@end
