//
//  AddressManagerController.h
//  vitagou
//
//  Created by 高坤 on 2017/7/28.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "GKBaseViewController.h"
#import "AddressManagerData.h"
@protocol SelectAddressDelegate <NSObject>
-(void)selectAddress:(AddressManagerData *)addressData;
@end
@interface AddressManagerController : GKBaseViewController
@property(nonatomic,assign) id<SelectAddressDelegate> delegate;
@property(nonatomic,assign) BOOL isOrderConfirm;
@end
