//
//  AddressCell.m
//  vitagou
//
//  Created by 高坤 on 2017/7/31.
//  Copyright © 2017年 Vitagou. All rights reserved.
//
/* by zxb 添加一个可共点击的 背景*/

#import "AddressCell.h"
#import "Color.h"
#import "AddressManagerData.h"
#import "VTGConstants.h"
#import "ManageAddressController.h"
#import "ExtraAddress.h"
@interface AddressCell ()
@property(nonatomic,strong)UILabel      *userName;
@property(nonatomic,strong)UILabel      *phone;
@property(nonatomic,strong)UILabel      *address;
@property(nonatomic,strong)UILabel      *card;
@property(nonatomic,strong)UILabel      *cardnumber;
@property(nonatomic,strong)UIButton      *edit;
@property(nonatomic,strong)UIButton      *delete;
@property(nonatomic,strong)AddressManagerData *addressData;


@end
@implementation AddressCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
        [self initView];
    }
    return self;
}

-(void)setData:(AddressManagerData *)data{
    self.addressData=data;
    self.userName.text = data.accept_name;
    self.phone.text=data.mobile;
    NSString *strAddress=[NSString stringWithFormat:@"%@%@%@%@",data.province_val,data.city_val,data.area_val,data.address];
    self.address.text=strAddress;
    self.cardnumber.text=data.Idcard;
    if([data.is_default isEqualToString:@"1"]){
        _selectBtn.selected=YES;
    }else{
        _selectBtn.selected=NO;
    }
    
}


- (void)initView
{
    self.selectionStyle     = UITableViewCellSelectionStyleNone;
    
    [self setUserInteractionEnabled:YES];

    self.userName       = [[UILabel alloc]init];
    _userName.textColor = GKCOLOR(80, 80, 80, 1);
    _userName.font      = [UIFont systemFontOfSize:13];
    [self addSubview:_userName];

    [_userName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(10);
        make.left.equalTo(self).offset(10);
    }];
    self.phone       = [[UILabel alloc]init];
    _phone.textColor = GKCOLOR(80, 80, 80, 1);
    _phone.font      = [UIFont systemFontOfSize:13];
    [self addSubview:_phone];

    [_phone mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(10);
        make.right.equalTo(self).offset(-10);
    }];
    self.address       = [[UILabel alloc]init];
    _address.textColor = GKCOLOR(80, 80, 80, 1);
    _address.font      = [UIFont systemFontOfSize:13];
    [self addSubview:_address];

    [_address mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_userName.mas_bottom).offset(10);
        make.left.equalTo(self).offset(10);
    }];
    self.card       = [[UILabel alloc]init];
    _card.textColor = GKCOLOR(80, 80, 80, 1);
    _card.text=vtgCard;
    _card.font      = [UIFont systemFontOfSize:13];
    [self addSubview:_card];

    [_card mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_address.mas_bottom).offset(15);
        make.left.equalTo(self).offset(10);
    }];
    self.cardnumber       = [[UILabel alloc]init];
    _cardnumber.textColor = GKCOLOR(80, 80, 80, 1);
    _cardnumber.font      = [UIFont systemFontOfSize:13];
    [self addSubview:_cardnumber];

    [_cardnumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.card.mas_right).offset(5);
        make.centerY.equalTo(self.card);
    }];
    
    

       
    UIView *line            = [[UIView alloc]init];
    line.backgroundColor    = GKCOLOR(199, 199, 199, 1);
    [self addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self);
        make.right.equalTo(self);
        make.top.equalTo(self.card.mas_bottom).offset(10);
//         make.top.equalTo(self.mClickBg.mas_bottom).offset(10);
        make.height.mas_equalTo(0.5);
    }];
    
    self.selectBtn       = [UIButton buttonWithType:UIButtonTypeCustom];
    [_selectBtn setImage:[UIImage imageNamed:@"ic_address_select"] forState:UIControlStateNormal];
    [_selectBtn setBackgroundImage: [UIImage imageNamed:@"ic_address_active"] forState:UIControlStateSelected ];
    [self addSubview:self.selectBtn];
    [self.selectBtn addTarget:self action:@selector(selectClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.selectBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(line.mas_bottom).offset(10);
        make.left.equalTo(self).offset(10);
        make.height.mas_equalTo(20);
        make.width.mas_equalTo(20);
    }];
    UILabel *lable      = [[UILabel alloc]init];
    lable.textColor = GKCOLOR(80, 80, 80, 1);
    lable.text=vtgIsDefault;
    lable.font      = [UIFont systemFontOfSize:13];
    [self addSubview:lable];
    [lable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_selectBtn);
        make.left.equalTo(_selectBtn.mas_right).offset(20);
    }];
    
    self.delete= [UIButton buttonWithType:UIButtonTypeCustom];
    [self addSubview:self.delete];
    _delete.titleLabel.font = [UIFont systemFontOfSize: 13];
    [_delete setTitleColor:GKCOLOR(80, 80, 80, 1) forState:UIControlStateNormal];
    _delete.tag=101;
    [_delete addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [_delete setTitle:vtgDelete forState:UIControlStateNormal];
    [_delete mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_selectBtn);
        make.right.equalTo(self).offset(-30);
        make.height.equalTo(@20);
        make.width.equalTo(@30);
    }];
    self.edit= [UIButton buttonWithType:UIButtonTypeCustom];
    [self addSubview:self.edit];
    _edit.titleLabel.font = [UIFont systemFontOfSize: 13];
    [_edit setTitleColor:GKCOLOR(80, 80, 80, 1) forState:UIControlStateNormal];
    _edit.tag=102;
    [_edit addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [_edit setTitle:vtgEdit forState:UIControlStateNormal];
    [_edit mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_selectBtn);
        make.right.equalTo(_delete.mas_left).offset(-30);
        make.height.equalTo(@20);
        make.width.equalTo(@30);
    }];


    UIView *bottomLine            = [[UIView alloc]init];
    bottomLine.backgroundColor    = GKCOLOR(246, 245, 246, 1);
    [self addSubview:bottomLine];
    [bottomLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self);
        make.right.equalTo(self);
        make.top.equalTo(_selectBtn.mas_bottom).offset(10);
        make.height.mas_equalTo(10);
    }];
}
-(void)selectClick:(UIButton *)btn{
   btn.selected =!btn.selected;
    _deleteId=[_addressData.address_id integerValue];
    btn.tag=_deleteId;
    [self.delegate didClickButton:btn];
}
-(void)btnClick:(UIButton *)btn
{
    ExtraAddress *address=[[ExtraAddress alloc]init];
    address.address_id=_addressData.address_id;
    address.accept_name=_addressData.accept_name;
    address.address=[[_addressData.province_val stringByAppendingString:_addressData.city_val] stringByAppendingString:_addressData.area_val ];
    address.address_detail=_addressData.address;
    address.mobile=_addressData.mobile;
    address.Idcard=_addressData.Idcard;
    address.province=_addressData.province;
    address.city=_addressData.city;
    address.area=_addressData.area;
    address.Idimg_zm=_addressData.Idimg_zm;
    address.Idimg_fm=_addressData.Idimg_fm;
        _deleteId=[_addressData.address_id integerValue];
        [self.delegate clickButton:btn extraAddress:address];

}

- (void)awakeFromNib {
    [super awakeFromNib];

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}


@end
