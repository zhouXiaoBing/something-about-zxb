//
//  CommentDa.m
//  vitagou
//
//  Created by 高坤 on 2017/8/2.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "CommentData.h"
#import "StringSize.h"
#define HD_CommonBgColor HD_Color(206,206,206);
#define KMainWidth [UIScreen mainScreen].bounds.size.width
#define KMainHeight  [UIScreen mainScreen].bounds.size.height
@implementation CommentData
+(NSDictionary *)mj_objectClassInArray
{
    return @{
             @"images" : @"CommentImages"
             };
}
-(CGFloat)cellHeight{
    if (_cellHeight == 0){
        _cellHeight = 55;
        CGSize maxSize = CGSizeMake(KMainWidth - 20, MAXFLOAT);
        CGSize titleSize =  [StringSize hehestringSizeWithSize:_contents font:16 textSizeMax:maxSize];
        _cellHeight  += titleSize.height ;
        if (!_contents.length) {
            _cellHeight -=  19.093750 + 10 ;
        }else if (titleSize.height > 500){
            _cellHeight += 20;
        }
        
        
        NSInteger count = self.images.count;
        if (count > 0) {
            
            
            CGFloat imageWH = (KMainWidth - 40 ) / 3;
            if (count <= 3) {
                CommentImages *img=[[CommentImages alloc]init];
                img=self.images[0];
                NSString *imgStr=img.img;
                if([imgStr isEqualToString:@""]){
                    _cellHeight=30;
                }
                else{
                    _cellHeight += imageWH  ;
                    
                }
            }else if( count > 3 && count <= 6){
                _cellHeight += 2* imageWH + 1 *10;
            }else if( count > 6 && count <= 9){
                _cellHeight += 3 * imageWH + 2 *10;
                
            }
        }
        _cellHeight +=45 +20 ;
    }
    return _cellHeight;
    
}

@end
