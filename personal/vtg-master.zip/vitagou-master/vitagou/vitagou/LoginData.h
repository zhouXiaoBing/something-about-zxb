//
//  LoginData.h
//  vitagou
//
//  Created by 高坤 on 2017/7/27.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LoginData : NSObject
@property (nonatomic,copy) NSString * user_token;
@end
