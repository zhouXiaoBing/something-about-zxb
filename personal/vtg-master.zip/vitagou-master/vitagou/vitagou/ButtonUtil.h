//
//  ButtonUtil.h
//  ETShop-for-iOS
//
//  Created by EleTeam(Tony Wong) on 15/8/25.
//  Copyright © 2015年 EleTeam. All rights reserved.
//
//  @email 908601756@qq.com
//
//  @license The MIT License (MIT)
//

#import <Foundation/Foundation.h>

@interface ButtonUtil : NSObject

+ (UIButton *)redButtonWithTitle:(NSString *)title;

@end
