//
//  CouponTicket.m
//  vitagou
//
//  Created by 高坤 on 2017/8/7.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "CouponTicket.h"

@implementation CouponTicket

@end
