//
//  UIKit.h>  @interface HomeHeaderCell : UICollectionReusableView  - (void)showTitleLable:(BOOL)show; @end  @interface HomeFooterCell : UICollectionReusableView  HomeHeaderCell.m
//  vitagou
//
//  Created by Mac on 2017/6/9.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>
