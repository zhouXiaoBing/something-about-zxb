//
//  DCCommentPicCell.h
//  CDDMall
//
//  Created by apple on 2017/6/27.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "goods_comment_data_content_img.h"

@class DCCommentPicItem;
@interface DCCommentPicCell : UICollectionViewCell

/* 图片评论 */
//@property (strong , nonatomic)DCCommentPicItem *picItem;

//@property(strong, nonatomic) NSString *img;

@property(strong, nonatomic) goods_comment_data_content_img *gcdcimg;

/* 图片 */
@property (strong , nonatomic)UIImageView *pciImageView;

@end
