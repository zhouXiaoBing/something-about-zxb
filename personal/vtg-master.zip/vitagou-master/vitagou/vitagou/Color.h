//
//  Color.h
//  vitagou
//
//  Created by 高坤 on 2017/6/29.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#ifndef Color_h
#define Color_h
#define WTKCOLOR(r, g, b, a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
#define BASE_COLOR WTKCOLOR(243, 243, 246, 1.0)
#define GKCOLOR(r, g, b, a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
#define RGBCOLOR(r,g,b) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:1]
#endif /* Color_h */
