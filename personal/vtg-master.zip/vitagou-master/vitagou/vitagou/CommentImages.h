//
//  CommentImages.h
//  vitagou
//
//  Created by 高坤 on 2017/8/2.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommentImages : NSObject
@property (nonatomic, strong) NSString *img;
@end
