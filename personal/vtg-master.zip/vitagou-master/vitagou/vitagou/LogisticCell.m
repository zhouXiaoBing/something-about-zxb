//
//  LogisticCell.m
//  vitagou
//
//  Created by 高坤 on 2017/8/23.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "LogisticCell.h"
#import "Color.h"
@interface LogisticCell()
@property(nonatomic,strong)UILabel *station;
@property(nonatomic,strong)UILabel *time;
@end
@implementation LogisticCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
        [self initView];
    }
    return self;
}
-(void)setData:(LogisticData *)data{
    _station.text=data.station;
    _time.text=data.time;
}
-(void) initView{
    UIView *lines            = [[UIView alloc]init];
    lines.backgroundColor    = GKCOLOR(199, 199, 199, 1);
    [self addSubview:lines];
    [lines mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(10);
        make.height.mas_equalTo(self);
        make.width.mas_equalTo(3);
    }];
    UIImageView *pointImg=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"ic_logistic"]];
    [self.contentView addSubview:pointImg];
    [pointImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.left.equalTo(self).offset(3);
        make.width.mas_equalTo(15);
        make.height.mas_equalTo(15);
    }];
    _station=[[UILabel alloc]init];
    _station.textColor = GKCOLOR(147, 172, 89, 1);
    _station.font      = [UIFont systemFontOfSize:12];
    _station.numberOfLines=2;
    [self addSubview:_station];
    [_station mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(10);
        make.left.equalTo(lines.mas_right).offset(20);
        make.right.equalTo(self).offset(-10);
    }];
    _time=[[UILabel alloc]init];
    _time.textColor = GKCOLOR(147, 172, 89, 1);
    _time.font      = [UIFont systemFontOfSize:12];
    [self addSubview:_time];
    [_time mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_station.mas_bottom).offset(10);
        make.left.equalTo(lines.mas_right).offset(20);
        make.bottom.equalTo(self).offset(-10);
        make.right.equalTo(self).offset(-10);
    }];

    UIView *line            = [[UIView alloc]init];
    line.backgroundColor    = GKCOLOR(199, 199, 199, 1);
    [self addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self);
        make.right.equalTo(self);
        make.bottom.equalTo(self).offset(-0.7);
        make.height.mas_equalTo(0.5);
    }];
}
- (void)awakeFromNib {
    [super awakeFromNib];

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

@end
