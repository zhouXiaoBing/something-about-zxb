//
//  GKBaseViewController.m
//  vitagou
//
//  Created by 高坤 on 2017/7/17.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "GKBaseViewController.h"
#import "MBProgressHUD.h"

@interface GKBaseViewController ()

@end

@implementation GKBaseViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.hidesBottomBarWhenPushed=YES;
    }
    return self;
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
        self.edgesForExtendedLayout = UIRectEdgeNone;
    
//    self.Use UIScrollView's contentInsetAdjustmentBehavior instead=NO;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapped:)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
        self.view.backgroundColor = [UIColor whiteColor];
}

//触摸其他地方，键盘消失
-(void)viewTapped:(UITapGestureRecognizer*)tap
{
    
    [self.view endEditing:YES];
}

-(void)initNagation{

    UIButton*leftButton = [[UIButton alloc]initWithFrame:CGRectMake(0,0,40,40)];
    [leftButton setImage:[UIImage imageNamed:@"ic_title_back_page"] forState:UIControlStateNormal];
    [leftButton addTarget:self action:@selector(titleBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem*leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem= leftItem;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) titleBack{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
