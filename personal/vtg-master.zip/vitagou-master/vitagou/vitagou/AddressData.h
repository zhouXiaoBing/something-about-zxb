//
//  AddressData.h
//  loveFreshPeak
//
//  Created by ArJun on 16/5/23.
//  Copyright © 2016年 AJun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AddressData : NSObject

@end
