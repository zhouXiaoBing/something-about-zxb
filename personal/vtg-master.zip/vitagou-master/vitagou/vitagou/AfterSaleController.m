//
//  AfterSaleController.m
//  vitagou
//
//  Created by 高坤 on 2017/8/31.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "AfterSaleController.h"
#import "VTGConstants.h"
#import "Color.h"
#import "HXPhotoViewController.h"
#import "HXPhotoView.h"
#import "ProgressView.h"
#import "UiTextViewPlaceholder.h"
#import "MBManager.h"
#import "PersonResult.h"
#import "RefundServiceViewController.h"
static const CGFloat kPhotoViewMargin = 12.0;
@interface AfterSaleController ()<HXPhotoViewDelegate>
@property (strong, nonatomic) UiTextViewPlaceholder *contentView;
@property (strong, nonatomic) HXPhotoManager *manager;
@property (strong, nonatomic) HXPhotoView *photoView;
@property (strong, nonatomic) UIScrollView *scrollView;
@property (strong, nonatomic) NSArray<HXPhotoResultModel *>*photos;
@end

@implementation AfterSaleController
- (HXPhotoManager *)manager {
    if (!_manager) {
        _manager = [[HXPhotoManager alloc] initWithType:HXPhotoManagerSelectedTypePhotoAndVideo];
        _manager.openCamera = YES;
        _manager.cacheAlbum = YES;
        _manager.lookLivePhoto = YES;
        _manager.open3DTouchPreview = YES;
        _manager.cameraType = HXPhotoManagerCameraTypeSystem;
        _manager.photoMaxNum = 3;
        _manager.videoMaxNum = 0;
        _manager.maxNum = 18;
        _manager.saveSystemAblum = NO;
    }
    return _manager;
}
- (void)viewDidLoad {
    
    [super viewDidLoad];
    [self.navigationController.navigationBar setTintColor:[UIColor blackColor]];
    [self initView];
}
-(void)initView{
    if(_status==2){
    self.title=vtgAfterSaleControllerChange;
    }else{
    self.title=vtgAfterSaleController;
    }
    self.view.backgroundColor=GKCOLOR(247, 247, 247, 1);
    self.edgesForExtendedLayout = UIRectEdgeNone;
    ProgressView *progressView=[[ProgressView alloc]init];
    [self.view addSubview:progressView];
    UILabel * number=[[UILabel alloc]init];
    number.textColor = GKCOLOR(49, 49, 49, 1);
    number.text=[vtgOrderNumber stringByAppendingString:_order_no];
    number.font      = [UIFont systemFontOfSize:13];
    [self.view addSubview:number];
    [number mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(progressView).offset(65);
        make.left.equalTo(self.view).offset(10);
    }];
    UIView *line          = [[UIView alloc]init];
    line.backgroundColor    = GKCOLOR(199, 199, 199, 1);
    [self.view addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(number.mas_bottom).offset(10);
        make.width.mas_equalTo(self.view.bounds.size.width);
        make.height.mas_equalTo(0.3);
    }];
    UILabel * sellerName=[[UILabel alloc]init];
    sellerName.textColor = GKCOLOR(49, 49, 49, 1);
    sellerName.text=[vtgSellerName stringByAppendingString:_sellerName];
    sellerName.font      = [UIFont systemFontOfSize:13];
    [self.view addSubview:sellerName];
    [sellerName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(line).offset(10);
        make.left.equalTo(self.view).offset(10);
    }];
    UIView *lineSecond          = [[UIView alloc]init];
    lineSecond.backgroundColor    = GKCOLOR(199, 199, 199, 1);
    [self.view addSubview:lineSecond];
    [lineSecond mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(sellerName.mas_bottom).offset(10);
        make.width.mas_equalTo(self.view.bounds.size.width);
        make.height.mas_equalTo(0.3);
    }];
    UIImageView * goodImg          = [[UIImageView alloc]init];
    [self.view addSubview:goodImg];
    [goodImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(lineSecond.mas_bottom);
        make.left.equalTo(self.view);
        make.height.mas_equalTo(80);
        make.width.mas_equalTo(80);
    }];
    [goodImg sd_setImageWithURL: [NSURL URLWithString:[vtgUrl stringByAppendingString:_goodsImage]]placeholderImage:[UIImage imageNamed:@"default_image"]];
    UILabel * goodName=[[UILabel alloc]init];
    goodName.textColor = GKCOLOR(49, 49, 49, 1);
    goodName.text=  _goodsArray ;
    goodName.numberOfLines=2;
    goodName.font      = [UIFont systemFontOfSize:13];
    [self.view addSubview:goodName];
    [goodName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(goodImg);
        make.left.equalTo(goodImg.mas_right).offset(10);
        make.right.equalTo(self.view).offset(-10);
    }];
    UIView *lineThird         = [[UIView alloc]init];
    lineThird.backgroundColor    = GKCOLOR(199, 199, 199, 1);
    [self.view addSubview:lineThird];
    [lineThird mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(goodImg.mas_bottom);
        make.width.mas_equalTo(self.view.bounds.size.width);
        make.height.mas_equalTo(0.5);
    }];
    UILabel * refundExplain=[[UILabel alloc]init];
    refundExplain.textColor = GKCOLOR(49, 49, 49, 1);
    refundExplain.text=  vtgRefundExplain ;
    refundExplain.font      = [UIFont systemFontOfSize:13];
    [self.view addSubview:refundExplain];
    [refundExplain mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(lineThird).offset(10);
        make.left.equalTo(self.view).offset(10);
    }];
    _contentView=[[UiTextViewPlaceholder alloc]init];
//    _contentView.backgroundColor=GKCOLOR(246, 246, 246, 1);
    _contentView.textColor = [UIColor darkGrayColor];
    _contentView.font = [UIFont systemFontOfSize:15];
    if(_status==2){
        _contentView.text=_content;
    }
    _contentView.textAlignment=UIDataDetectorTypeAll;
    _contentView.placeholderString=vtgRefundHint;
    _contentView.isChangeHeight = NO;
    [self.view addSubview:_contentView];
    [_contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(refundExplain.mas_bottom).offset(10);
        make.left.equalTo(self.view).offset(10);
        make.right.equalTo(self.view).offset(-10);
        make.height.mas_equalTo(70);
        make.width.mas_equalTo(self.view.bounds.size.width);
    }];
    UILabel * refundImg=[[UILabel alloc]init];
    refundImg.textColor = GKCOLOR(49, 49, 49, 1);
    refundImg.text=  vtgRefundUploadImg ;
    refundImg.font      = [UIFont systemFontOfSize:15];
    [self.view addSubview:refundImg];
    [refundImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_contentView.mas_bottom).offset(10);
        make.left.equalTo(self.view).offset(10);
    }];
 
    UIButton *commitButton = [UIButton buttonWithType:UIButtonTypeCustom];
    commitButton.backgroundColor=GKCOLOR(205, 8, 50, 1);
    commitButton.titleLabel.font = [UIFont systemFontOfSize: 16];
    [commitButton addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [commitButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [commitButton setTitle:vtgRefundSubmit forState:UIControlStateNormal];
    [self.view addSubview:commitButton];
    [commitButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view);
        make.left.equalTo(self.view);
        make.bottom.equalTo(self.view);
        make.height.mas_equalTo(50);
        
    }];

    //选择照片
    self.automaticallyAdjustsScrollViewInsets = YES;
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    scrollView.alwaysBounceVertical = NO;
     scrollView.scrollEnabled = NO;
    [self.view addSubview:scrollView];
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(refundImg.mas_bottom).offset(10);
        make.height.mas_equalTo(100);
        make.width.mas_equalTo(self.view.bounds.size.width);
    }];
    
    self.scrollView = scrollView;
    
    CGFloat width = scrollView.frame.size.width;
    HXPhotoView *photoView = [HXPhotoView photoManager:self.manager];
    photoView.frame = CGRectMake(kPhotoViewMargin, kPhotoViewMargin, width - kPhotoViewMargin * 2, 0);
    photoView.delegate = self;
    photoView.backgroundColor = GKCOLOR(246, 246, 246, 1);
    [scrollView addSubview:photoView];
    self.photoView = photoView;

}
- (void)photoView:(HXPhotoView *)photoView changeComplete:(NSArray<HXPhotoModel *> *)allList photos:(NSArray<HXPhotoModel *> *)photos videos:(NSArray<HXPhotoModel *> *)videos original:(BOOL)isOriginal {
       [HXPhotoTools getSelectedListResultModel:allList complete:^(NSArray<HXPhotoResultModel *> *alls, NSArray<HXPhotoResultModel *> *photos, NSArray<HXPhotoResultModel *> *videos) {
        NSSLog(@"照片:%@",photos);
        _photos=photos;
    }];
}

- (void)photoView:(HXPhotoView *)photoView updateFrame:(CGRect)frame {
    self.scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width, CGRectGetMaxY(frame) + kPhotoViewMargin);
    
}



-(void)btnClick{
    if(_contentView.text.length==0){
     [MBManager showBriefAlert:vtgRefundHint];
    }
    else{
        [MBManager showWaitingWithTitle:vtgIsCommentSend ];
        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:vtgTEXTORHTML];
        NSDictionary *dict;
        NSString *content=[_contentView.text stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        if(_photos!=nil){
            if(_status==2){
                dict = @{vtgParams_token:[[NSUserDefaults standardUserDefaults] objectForKey:vtgParams_token],
                         vtgParams_RefundId:_refundId,vtgParams_Refund_Content:content,vtgParams_IsIMG:vtgParams_NotUser};
            }else{
            dict = @{vtgParams_token:[[NSUserDefaults standardUserDefaults] objectForKey:vtgParams_token],vtgParams_Order_Id:_order_id,
                     vtgParams_goodsId:_goods_id,vtgParams_Refund_Content:content,vtgParams_IsIMG:vtgParams_NotUser};
            }
        }else{
            if(_status==2){
                dict = @{vtgParams_token:[[NSUserDefaults standardUserDefaults] objectForKey:vtgParams_token],
                         vtgParams_RefundId:_refundId,vtgParams_Refund_Content:content};
            }else{
            dict = @{vtgParams_token:[[NSUserDefaults standardUserDefaults] objectForKey:vtgParams_token],vtgParams_Order_Id:_order_id,
                     vtgParams_goodsId:_goods_id,vtgParams_Refund_Content:content};
            }
        }
        NSString *URL;
        if(_status==2){
            URL=AFTER_SALE_CHANGE;
        }else{
            URL=AFTER_SALE_COMMENT;
        }
        [manager POST:URL parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
            if(_photos!=nil){
                for(NSInteger i = 0; i < _photos.count; i++)
                {
                    UIImage * selectImg =_photos[i].displaySizeImage;
                    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                    formatter.dateFormat = vtgdata;
                    NSString *str = [formatter stringFromDate:[NSDate date]];
                    UIImage *image = selectImg;
                    NSData *imageData = UIImageJPEGRepresentation(image, 1.0);
                    NSString *img=[vtgScreenShot stringByAppendingString:str];
                    NSString *fileName = [NSString stringWithFormat:@"%@.png", img];
                    
                    [formData appendPartWithFileData:imageData name:vtgFileUpload fileName:fileName mimeType:@"image/jpeg"];
                }
            }
        }success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSLog(@"%@", responseObject);
            PersonResult *result=[[PersonResult alloc]init];
            result = [PersonResult mj_objectWithKeyValues:responseObject[@"result"]];
            if([result.msg isEqualToString:@"success"]){
                [MBManager hideAlert];
                [self.delegate breakSuccessButton];
                if(_status==2){
                    [MBManager showBriefAlert:vtgChangeSuccess];
                     [self.navigationController popViewControllerAnimated:YES];
                }else{
                RefundServiceViewController *view=[[RefundServiceViewController alloc]init];
                view.order_id=_order_id;
                view.orderNumber=_order_no;
                view.goodsId=_goods_id;
                view.goodsArray=_goodsArray;
                view.sellerName=_sellerName;
                view.serllerId=_sellerId;
                view.img=_goodsImage;
                [self.navigationController pushViewController:view animated:YES];
                }
            }
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            [MBManager hideAlert];
            NSLog(@"%@", error);
        }];

    }

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];

}



@end
