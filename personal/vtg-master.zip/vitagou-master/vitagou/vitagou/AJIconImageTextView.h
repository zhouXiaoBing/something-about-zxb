//
//  AJIconImageTextView.h
//  loveFreshPeak
//
//  Created by ArJun on 16/6/7.
//  Copyright © 2016年 阿俊. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AJIconImageTextView : UIView
+ (instancetype)IconImageTextView:(NSString *)image title:(NSString *)title placeHolder:(UIImage *)placeHolder;
@end
