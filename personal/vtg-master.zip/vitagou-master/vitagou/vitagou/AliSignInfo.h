//
//  AliSignInfo.h
//  vitagou
//
//  Created by Mac on 2017/11/2.
//  Copyright © 2017年 Vitagou. All rights reserved.
//


@interface AliSignInfo : NSObject

@property (nonatomic, strong) NSString *data;

@property (nonatomic, strong) NSString *status;

@property (nonatomic, strong) NSString *msg;


+(void)getAliSignInfo:(NSString *)user_token
           order_id:(NSString *)order_id
            success:(void(^)(AliSignInfo *data))success
            failure:(void(^)(NSError *error))failure;

@end
