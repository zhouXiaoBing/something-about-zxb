//
//  CartNoDataView.h
//  vitagou
//
//  Created by 高坤 on 2017/12/11.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CartNoDataView : UIView
- (instancetype)init;
@end

