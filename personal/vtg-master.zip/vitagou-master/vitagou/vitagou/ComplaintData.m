//
//  ComplaintData.m
//  vitagou
//
//  Created by 高坤 on 2017/8/9.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "ComplaintData.h"

@implementation ComplaintData

@end
