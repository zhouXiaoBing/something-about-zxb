//
//  AddressManagerData.m
//  vitagou
//
//  Created by 高坤 on 2017/7/31.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "AddressManagerData.h"

@implementation AddressManagerData

@end
