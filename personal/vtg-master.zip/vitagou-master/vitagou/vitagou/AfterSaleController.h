//
//  AfterSaleController.h
//  vitagou
//
//  Created by 高坤 on 2017/8/31.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import "GKBaseViewController.h"
@protocol AfterSaleDelegate <NSObject>
-(void)breakSuccessButton;
@end
@interface AfterSaleController : GKBaseViewController
@property (nonatomic) NSInteger status;
@property (nonatomic ,strong)NSString *order_id;
@property (nonatomic ,strong)NSString *order_no;
@property (nonatomic ,strong)NSString *goods_id;
@property (nonatomic ,strong)NSString *amount;
@property (nonatomic ,strong)NSString *asstatus;
@property (nonatomic ,strong)NSString *goodsArray;
@property (nonatomic ,strong)NSString *goodsImage;
@property (nonatomic ,strong)NSString *sellerName;
@property (nonatomic ,strong)NSString *sellerId;
@property (nonatomic ,strong)NSString *refundId;
@property (nonatomic ,strong)NSString *content;
@property(nonatomic,assign) id<AfterSaleDelegate> delegate;
@end
