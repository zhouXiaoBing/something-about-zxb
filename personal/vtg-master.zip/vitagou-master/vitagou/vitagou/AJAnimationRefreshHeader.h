//
//  AJAnimationRefreshHeader.h
//  loveFreshPeak
//
//  Created by ArJun on 16/8/9.
//  Copyright © 2016年 阿俊. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface AJAnimationRefreshHeader : MJRefreshGifHeader

@end
