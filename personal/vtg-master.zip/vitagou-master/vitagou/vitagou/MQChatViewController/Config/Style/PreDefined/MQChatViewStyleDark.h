//
//  MQChatViewStyleDark.h
//  Meiqia-SDK-Demo
//
//  Created by ian luo on 16/3/30.
//  Copyright © 2016年 ijinmao. All rights reserved.
//

#import "MQChatViewStyle.h"

@interface MQChatViewStyleDark : MQChatViewStyle

@end
