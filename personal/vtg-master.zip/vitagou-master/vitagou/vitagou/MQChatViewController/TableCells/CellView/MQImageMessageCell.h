//
//  MQImageMessageCell.h
//  MeiQiaSDK
//
//  Created by ijinmao on 15/10/29.
//  Copyright © 2015年 MeiQia Inc. All rights reserved.
//

#import "MQImageMessageCell.h"
#import "MQImageCellModel.h"
/**
 * MQImageMessageCell定义了客服聊天界面的图片消息cell
 */
@interface MQImageMessageCell : MQChatBaseCell



@end
