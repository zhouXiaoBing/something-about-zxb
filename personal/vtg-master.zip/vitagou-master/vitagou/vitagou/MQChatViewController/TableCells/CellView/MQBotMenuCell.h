//
//  MQBotMenuCell.h
//  MQChatViewControllerDemo
//
//  Created by ijinmao on 16/4/27.
//  Copyright © 2016年 ijinmao. All rights reserved.
//

#import "MQChatBaseCell.h"

@interface MQBotMenuCell : MQChatBaseCell

@end
