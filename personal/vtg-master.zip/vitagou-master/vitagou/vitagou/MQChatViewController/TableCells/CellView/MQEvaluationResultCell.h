//
//  MQEvaluationResultCell.h
//  MQChatViewControllerDemo
//
//  Created by ijinmao on 16/3/1.
//  Copyright © 2016年 ijinmao. All rights reserved.
//

#import "MQChatBaseCell.h"

/**
 * MQEvaluationCell 定义了客服聊天界面的评价结果的 Cell
 */
@interface MQEvaluationResultCell : MQChatBaseCell

@end
