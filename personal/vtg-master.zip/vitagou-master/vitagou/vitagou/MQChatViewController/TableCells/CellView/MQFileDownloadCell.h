//
//  MQFileDownloadCell.h
//  Meiqia-SDK-Demo
//
//  Created by ian luo on 16/4/6.
//  Copyright © 2016年 ijinmao. All rights reserved.
//

#import "MQChatBaseCell.h"

@interface MQFileDownloadCell : MQChatBaseCell

@end
