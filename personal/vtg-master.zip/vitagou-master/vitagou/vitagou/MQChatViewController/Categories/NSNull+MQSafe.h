//
//  NSNull+Safe.h
//  Meiqia-SDK-Demo
//
//  Created by ian luo on 16/5/31.
//  Copyright © 2016年 Meiqia. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSNull(MQSafe)

@end
