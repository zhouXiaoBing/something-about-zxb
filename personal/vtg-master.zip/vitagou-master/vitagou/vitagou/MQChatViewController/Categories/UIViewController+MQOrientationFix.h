//
//  UIViewController_Orientation.h
//  GrubbyWorm
//
//  Created by ian luo on 16/3/14.
//  Copyright © 2016年 GAME-CHINA.ORG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIViewController(MQOrientationFix)

@end
