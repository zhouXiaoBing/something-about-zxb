//
//  MQBotRickTextMessage.m
//  Meiqia-SDK-Demo
//
//  Created by ian luo on 16/8/8.
//  Copyright © 2016年 Meiqia. All rights reserved.
//

#import "MQBotRichTextMessage.h"

@interface MQBotRichTextMessage()

@end

@implementation MQBotRichTextMessage

@end
