//
//  BadgeButton.h
//  vitagou
//
//  Created by 高坤 on 2017/7/4.
//  Copyright © 2017年 Vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BadgeButton : UIButton
@property (nonatomic) NSInteger badgeValue;

@property (nonatomic, assign) BOOL isRedBall;
@end
