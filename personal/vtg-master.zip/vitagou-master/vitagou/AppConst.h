//
//  AppConst.h
//  vitagou
//
//  Created by Mac on 2017/5/9.
//  Copyright © 2017年 Vitagou. All rights reserved.
//
#import <UIKit/UIKit.h>

extern NSString * const IsFristOpenApp;
extern NSString * const GuideViewControllerDidFinish;
extern NSString * const HomeTableHeadViewHeightDidChange;
extern NSString * const ProductHeadViewHeightDidChange;

extern NSString * const HomeGoodsInventoryProblem;
extern NSString * const LFBShopCarDidRemoveProductNSNotification;
extern NSString * const LFBShopCarBuyNumberDidChangeNotification;

extern NSString * const ProductGoodsId;
extern NSString * const MenuViewNotification;
extern NSString * const WheelUrlNotification;


extern NSString * const PageNumberDidChangeNotification;
extern NSString * const CurrentPageDidChangeNotification;
extern NSString * const SelectedProductCountDidChangeNotification;
extern NSString * const ProductInfoDidRecievedNotification;
extern NSString * const ProductBuyCountDidChangeNotification;
extern NSString * const ClassifyNotification;
extern NSString * const BenifitToGoodDetailNotifacation;
extern NSString * const BrandCategoryNotification;
extern NSString * const FitPeopleCellNotifacation;
extern NSString * const BenifitNotification;
extern NSString * const ProductDetailAndCommentsChangeNotification;
//shopCart
extern NSString * const GoodsBeChoosedNotNotification;
extern NSString * const GoodsBeChoosedNotification;
extern NSString * const GoodsNumEditNotification;
extern NSString * const GoodsSettlementNotification;
extern NSString * const GoodsDelNotification;

//订单确认
extern NSString * const OrderConfirmChangeAddress;
extern NSString * const OrderConfirmWeChatPay;
extern NSString * const OrderConfirmALiPay;
extern NSString * const OrderConfirmDiscounts;
extern NSString * const OrderConfirmClickPay;
extern NSString * const OrderConfirmTransmitAddressData;
extern NSString * const OrderConfirmNeedsItDismissAddressManager;
extern NSString * const OrderConfirmGnerate;
extern NSString * const OrderConfirmGotoMyorder;
extern NSString * const OrderConfirmDiscount;

extern const CGFloat HomeCollectionViewCellMargin;
extern const CGFloat DefaultMargin;
