package com.jindanzi.zhishun.constant;

/**
 * Created by Administrator on 2017/8/16.
 */

public class Config {
    public static String IP = "http://125.227.206.31:136/AcuLife/";
}
