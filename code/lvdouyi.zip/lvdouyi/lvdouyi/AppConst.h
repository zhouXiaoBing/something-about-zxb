//
//  AppConst.h
//  lvdouyi
//
//  Created by Mac on 2018/9/13.
//  Copyright © 2018年 vitagou. All rights reserved.
//

#import <UIKit/UIKit.h>

extern NSString * const IsFirstOpenApp;//判断是否首次启动
