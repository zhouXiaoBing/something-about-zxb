//
//  shareBean.m
//  lvdouyi
//
//  Created by Mac on 2018/9/12.
//  Copyright © 2018年 vitagou. All rights reserved.
//

#import "shareBean.h"

@implementation shareBean


@end
