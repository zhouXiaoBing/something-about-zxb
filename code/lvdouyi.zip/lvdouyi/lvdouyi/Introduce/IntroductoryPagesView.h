//
//  IntroductoryPagesView.h
//  lvdouyi
//
//  Created by Mac on 2018/9/7.
//  Copyright © 2018年 vitagou. All rights reserved.
//

#import <UIKit/UIkit.h>

@interface IntroductoryPagesView : UIView

+ (instancetype)pagesViewWithFrame:(CGRect)frame images:(NSArray<NSString *> *)images;

@end


